import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { college } from './college';

@Injectable({
  providedIn: 'root'
})
export class GetdataService {


  // fileurl Contain the path of .json file 
  fileurl: string = './assets/college.json'


//httpclient used to fetch external data and post to external data 
  constructor(private http: HttpClient) { }

//This method used to get the data from filepath and its 
//return type is observable
  getData(): Observable<college> {
    return this.http.get<college>(this.fileurl)
  }

}