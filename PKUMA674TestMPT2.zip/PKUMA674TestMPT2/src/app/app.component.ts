import { Component, OnInit } from '@angular/core';
import { college } from './college';
import { GetdataService } from './getdata.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'MPT2';

  //creating Array of college that hold the json data
  collegeData: college[] = [];

  crud: GetdataService;
   //object of serviceClass created using constructor 
  constructor(private cd: GetdataService) {
  }
  loadData() {
    this.cd.getData().subscribe((data: any) => { this.collegeData = data })
  }

  ngOnInit() {
    this.loadData();
  }


  //This method delete the particular row of data when one 
  //click on delete button 
  deleteClg(collegeId) {
    for (var i = 0; i < this.collegeData.length; i++) 
    {
      if ((this.collegeData[i].collegeId) == collegeId) 
      {
        this.collegeData.splice(i, 1)
      }
    }
  }
 
  //Sort the Id column in ascending order 
  //here i used the bubble sort
  sortById() {
    for (let i = 0; i < this.collegeData.length; i++)
     {
      for (let j = 0; j < this.collegeData.length - 1; j++) 
      {
        if (this.collegeData[j]["collegeId"] > this.collegeData[j + 1]["collegeId"]) 
        {
          let temp=this.collegeData[j];
          this.collegeData[j]=this.collegeData[j + 1];
          this.collegeData[j + 1]=temp;
        }

      }
    }
  }

    //Sort the college name column in ascending order 
  //here i used the bubble sort
  sortByCollegeName() {
    for (let i = 0; i < this.collegeData.length; i++) 
    {
      for (let j = 0; j < this.collegeData.length - 1; j++)
       {
        if (this.collegeData[j]["collegeName"] > this.collegeData[j + 1]["collegeName"]) 
        {
          let temp=this.collegeData[j];
          this.collegeData[j]=this.collegeData[j + 1];
          this.collegeData[j + 1]=temp;
        }

      }
    }
  }


   //Sort the State column in ascending order 
  //here i used the bubble sort
  sortByState() {
    for (let i = 0; i < this.collegeData.length; i++)
     {
      for (let j = 0; j < this.collegeData.length - 1; j++)
       {
        if (this.collegeData[j]["state"] > this.collegeData[j + 1]["state"]) 
        {
          let temp=this.collegeData[j];
          this.collegeData[j]=this.collegeData[j + 1];
          this.collegeData[j + 1]=temp;
        }

      }
    }

  }
}
