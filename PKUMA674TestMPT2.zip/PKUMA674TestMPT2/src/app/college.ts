export class college
{
    collegeId:number;
    collegeName:string;
    state:string;

    constructor(collegeId:number,collegeName:string,state:string)
    {
        this.collegeId=collegeId;
        this.collegeName=collegeName;
        this.state=state;
    }
}