package com.cg.calc.lam;

@FunctionalInterface
public interface CalcService 
{
	//int fun(int args);
	boolean isValidName(String name);
}
