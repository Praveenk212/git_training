package com.cg.calc.lam;

import java.util.Arrays;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class CalcServiceImpl  {

	public static void main(String[] args) {
		
		
//		CalcService cal = (num1) ->
//		{
//			return num1;
//		};
//		System.out.println(cal.fun(9));
		
//		CalcService cal = (name)  ->
//		{
//			Matcher match=null;
//			Pattern ValidName=Pattern.compile("[A-Z][a-z]{2,10}");
//			match =ValidName.matcher(name);
//			return match.matches();
//		};
//		
//		System.out.println(cal.isValidName("Praveen"));
		
		Consumer<Integer> cons=(num)-> System.out.println(num+5);
		Predicate<Integer> intPre= (num) -> 
		{
			return(
				Pattern.matches("[0-9]{4}",String.valueOf(num)));
		};
		System.out.println(intPre.test(1009));
		
		
		Arrays.asList(1,5,6).forEach(System.out::println);
		
		
		
	}


}
