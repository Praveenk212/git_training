
public class CurrentAccount extends Account {
	
	int overDraftLimit=0;
	@Override
	public void withDraw(double d)
	{
		if((balance-d)<overDraftLimit)
		{
			System.out.println("Money in your account goes below 0 if withdrawn");
		}
		else
		{
			balance=balance-d;
		}
	}

}
