
public class Account {
	
	private long accNum;
	protected double balance=500;
	private Person accHolder;
	
	public void deposit(double d)
	{
		balance=balance+d;
		
	}
	public void withDraw(double d)
	{
		if((balance-d)<500)
		{
			System.out.println("You have Insufficient balance");
		}
		else
		{
			balance=balance-d;
		}
		
	}
	@Override
	public String toString() {
		return " Balance="+ getBalance() + ", Account Number=" + getAccNum() +
				", Account Holder =" + getAccHolder() + "]";
	}
	public double getBalance()
	{
		double bal = balance;
		return bal;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	

}
