import java.util.Random;

public class TestAccount {
	static Random rand=new Random();
	
	public static long generateAccNum()
	{
		String accNo="";
		for(int i=0;i<12;i++)
		{
			accNo=accNo+rand.nextInt(10);
		}
		return (Long.parseLong(accNo));
		
	}
	
	public static void main(String[] args) {
		
		Account Smith=new Account();
		Person p=new Person();
		p.setName("Smith");
		p.setAge(25);
		Smith.setAccHolder(p);
		Smith.setBalance(2000);
		Smith.setAccNum(generateAccNum());
		Smith.deposit(2000);
		System.out.println(Smith);
		Account Kathy=new Account();
		p.setName("Kathy");
		p.setAge(25);
		Kathy.setAccHolder(p);
		Kathy.setBalance(3000);
		Kathy.setAccNum(generateAccNum());
		Kathy.withDraw(2000);
		Kathy.withDraw(700);
		System.out.println(Kathy);
	}

}
