
public class SavingAccount extends Account{

	final double minimumBal=500;
	@Override
	public void withDraw(double d)
	{
		if((balance-d)<minimumBal)
		{
			System.out.println("You have Insufficient balance");
		}
		else
		{
			balance=balance-d;
		}
	}
		
}
