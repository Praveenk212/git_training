package com.cg.age.bean;

public class AgeComponent
{
	AgeComponent ac=null;
	
	public boolean isValidAge(int age)
	{
		boolean  flag;
		if(age>0 && age<100)
		{
			flag=true;;	
		}
		else if(age<0)
		{
			throw (new CustomException());
		}
		else
		{
			flag=false;
		}
		
	
		return flag;
	}

	
}
