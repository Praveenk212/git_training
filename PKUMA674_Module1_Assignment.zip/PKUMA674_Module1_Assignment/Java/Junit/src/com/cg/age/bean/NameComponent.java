package com.cg.age.bean;

public class NameComponent 
{
	
	public boolean isValidName(String name)
	{
		return name.matches("[A-Z][a-z]{2,20}");
	}

}
