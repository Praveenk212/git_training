package com.cg.age.bean;

public class CustomException extends RuntimeException

{
public CustomException()
{
	
}
	
	
}
