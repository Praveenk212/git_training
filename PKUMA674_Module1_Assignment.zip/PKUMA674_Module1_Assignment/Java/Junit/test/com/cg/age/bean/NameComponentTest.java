package com.cg.age.bean;

import static org.junit.Assert.*;

import org.junit.Test;

public class NameComponentTest {

	
	@Test
	public void testIsValidName() {
		
	    NameComponent nc=new NameComponent();
	    assertTrue(nc.isValidName("Praveen"));
		//fail("Not yet implemented");
	}

}
