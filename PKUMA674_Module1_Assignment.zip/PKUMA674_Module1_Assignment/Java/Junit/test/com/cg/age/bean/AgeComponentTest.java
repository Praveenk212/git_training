package com.cg.age.bean;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class AgeComponentTest {
	AgeComponent ac;
   
	@Test
	public void testIsValidAge() throws CustomException {
		
	     boolean b=ac.isValidAge(16);
	    assertTrue(b);
		//fail("Not yet implemented");
	}
   
	@Test(expected=CustomException.class)
	public void testIsValidAgeWith_veValue() {
		
	    AgeComponent ac=new AgeComponent();
	    boolean b=ac.isValidAge(-16);
	    assertFalse(b);
		//fail("Not yet implemented");
	}
	
	
	
	@Before
	public void start()
	{
		ac=new AgeComponent();
		System.out.println("start");
	}
	@After
	public void stop()
	{
		ac=null;
		System.out.println("stop");
	}

}
