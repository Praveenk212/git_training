package com.cg.age.bean;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ AgeComponentTest.class, AllTest.class, NameComponentTest.class })
public class AllTests {

}
