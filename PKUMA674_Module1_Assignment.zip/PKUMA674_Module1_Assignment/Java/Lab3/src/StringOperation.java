
public class StringOperation {
	
	public String addToSelf(String str)
	{
		return (str+str);
	}
	public String replaceOdd(String str)
	{
		String res="";
		for(int i=0;i<str.length();i++)
		{
			if(i%2==0)
			{
				res=res+("#");
			}
			else
			{
				res=res+(str.charAt(i));
			}
		}
		return res;
	}
	public String removeDup(String str)
	{
		String toBeReturned="";
		for(int i=0;i<str.length();i++)
		{
			char ch=str.charAt(i);
			if(toBeReturned.indexOf(ch)<0)
			{
				toBeReturned=toBeReturned+ch;
			}
		}
		return toBeReturned;
	}
	public String oddToUpper(String str)
	{
		String res="";
		for(int i=0;i<str.length();i++)
		{
			if(i%2==0)
			{
				res=res+(""+str.charAt(i)).toUpperCase();
			}
			else
			{
				res=res+(str.charAt(i));
			}
		}
		return res;
	}

}
