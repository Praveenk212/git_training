
public class TestStringOperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringOperation StOp=new StringOperation();
		System.out.println(StOp.addToSelf("Praveen"));
		System.out.println(StOp.replaceOdd("Praveen"));
		System.out.println(StOp.removeDup("Praveen"));
		System.out.println(StOp.oddToUpper("Praveen"));
	}

}
