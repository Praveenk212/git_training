package com.cg.eis.service;
import com.cg.eis.bean.*;
import com.cg.eis.exception.*;

import java.util.Scanner;

public class Service implements EmployeeService {
	
	@Override
	public Employee getEmpDetail() {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		Employee ed=new Employee();
		System.out.println("Enter Employee Id:");
		ed.setEmpId(s.nextInt());
		System.out.println("Enter Employee Name:");
		ed.setName(s.next());
		System.out.println("Enter Employee Salary:");
		float sal=s.nextFloat();
		if(sal<3000)
		{
			try {
				throw new EmployeeException();
			} catch (EmployeeException e) {
				System.out.println(e);
				System.exit(0);
			}
		}
		else
		{		
		ed.setSalary(sal);
		}
		return ed;
	}
	
      String insSc;
	@Override
	public String setInsScheme(float Salary) 
	{
		// TODO Auto-generated method stub
		if(Salary>5000 && Salary<20000)
		{
			insSc = "Scheme C";
		}
		else if(Salary>=20000 && Salary<40000)
		{
			insSc = "Scheme B";
		}
		else if(Salary>=40000)
		{
			insSc = "Scheme A";
		}
		else
		{
			insSc = "No Scheme";
		}
		return insSc;
	}
	
	
	@Override
	public void dispEmp(Employee e)
	{
		System.out.println("Employee Detail:\n"+e);
	}

    String desig;
	@Override
	public String setDesig(float Salary) {
		// TODO Auto-generated method stub
		if(Salary>5000 && Salary<20000)
		{
			desig = "System Associate";
		}
		else if(Salary>=20000 && Salary<40000)
		{
			desig = "Programmer";
		}
		else if(Salary>=40000)
		{
			desig = "Manager";
		}
		else
		{
			desig = "Clark";
		}
		return desig;
	}

}
