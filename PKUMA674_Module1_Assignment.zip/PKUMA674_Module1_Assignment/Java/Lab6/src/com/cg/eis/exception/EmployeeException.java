package com.cg.eis.exception;

public class EmployeeException extends Exception {

	public EmployeeException() 
	{
		super();
	}
	public String toString()
	{
		return "Please enter Salary greater than 3000";
	}

}
