package com.cg.eis.pl;
import com.cg.eis.bean.*;
import com.cg.eis.service.*;

public class TestEmployee {

	public static void main(String[] args) {
		Service s=new Service();
		Employee e=s.getEmpDetail();
		String scheme=s.setInsScheme(e.getSalary());
		e.setInsScheme(scheme);
		String desig=s.setDesig(e.getSalary());
		e.setDesig(desig);
		s.dispEmp(e);
		
		
	}

}
