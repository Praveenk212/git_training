package com.cg.eis.service;

import com.cg.eis.bean.*;

public interface EmployeeService {
	
	public Employee getEmpDetail();
	public String setInsScheme(float Salary);
	public String setDesig(float Salary);
	public void dispEmp(Employee e);
	

}
