package com.cg.eis.bean;

public class Employee {
	
	int empId;
	String name;
	float salary;
	String desig;
	String insScheme;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public String getDesig() {
		return desig;
	}
	
	public String getInsScheme() {
		return insScheme;
	}
	public void setDesig(String desig) {
		this.desig = desig;
	}
	public void setInsScheme(String insScheme) {
		this.insScheme = insScheme;
	}
	public Employee() {
		super();
	}
	public Employee(int empId, String name, float salary, String desig, String insScheme) {
		super();
		this.empId = empId;
		this.name = name;
		this.salary = salary;
		this.desig = desig;
		this.insScheme = insScheme;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", salary=" + salary + ", desig=" + desig
				+ ", insScheme=" + insScheme + "]";
	}
	
	
	
	

}
