import java.util.Scanner;

public class TestEmplDemo {

	public static void main(String[] args) {
		Employee Shubham=new Employee(111,"Shubham",3212.00F);
		Employee Sahil=new Employee(111,"Shubham",3212.00F);
		System.out.println("Shubham Info :"+
		           Shubham + "Annual Salary :"+
				   Shubham.CalcEmpAnnualSal());
		System.out.println("Sahil Info :"+
		           Sahil + "Annual Salary :"+
				   Sahil.CalcEmpAnnualSal());
		WageEmp Rajat=new WageEmp(113,"Rajat",10002.0F,4,500);
		System.out.println("Rajat Info :"+
		           Rajat + "Annual Salary :"+
				   Rajat.CalcEmpAnnualSal());
	
	Employee Praveen=new WageEmp(114,"Praveen",10002.0F,4,500);
	System.out.println("Rajat Info :"+
			Praveen + "Annual Salary :"+
			Praveen.CalcEmpAnnualSal());
	System.out.println(Shubham==Sahil);
	System.out.println(Shubham.equals(Sahil));

	}

}
