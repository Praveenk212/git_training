
public class TestStringDemo {
	public static void main(String[] args) 
	{
		String str1="Capgemini";
		String str2="Capgemini India";
		String str3="Capgemini";
		String str4=new String("Capgemini");
		String str5=new String("Capgemini");
		
		System.out.println("str1 hashcode:"+ (str1.hashCode()));
		System.out.println("str3 hashcode:"+ (str3.hashCode()));
		System.out.println("str4 hashcode:"+ (str4.hashCode()));
		
		System.out.println("str1==str2:"+ (str1==str2));
		System.out.println("str1==str3:"+ (str1==str3));
		System.out.println("str1==str4:"+ (str1==str4));
		System.out.println("str4==str5:"+ (str4==str5));
		
		System.out.println("str1==str3:"+ (str1.equals(str3)));
		System.out.println("str1==str2:"+ (str1.equals(str2)));
		System.out.println("str1==str4:"+ (str1.equals(str4)));
		System.out.println("str4==str5:"+ (str4.equals(str5)));
		
	}

}
