
public class WageEmp extends Employee{
	
	private int ratePerHour;
	private int noOfHrs;
	@Override
	public String toString() {
		return super.toString()+ "WageEmp [ratePerHour=" + ratePerHour + 
				", noOfHrs=" + noOfHrs + "]";
	}
	public WageEmp() {
	}
	public WageEmp(int empId, String empName, float empBasicSal,
			int ratePerHour, int noOfHrs) 
	{
		super(empId, empName, empBasicSal);
		this.ratePerHour = ratePerHour;
		this.noOfHrs = noOfHrs;
	}
	@Override
	public float calcEmpGrossSal()
	{
		return super.calcEmpGrossSal()+(ratePerHour*noOfHrs*20);
	}
	public  float CalcWageEmpAnnualSal()
	{
		return calcEmpGrossSal()*12;
	}
}
