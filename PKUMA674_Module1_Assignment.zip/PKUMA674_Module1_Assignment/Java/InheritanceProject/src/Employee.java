
public class Employee {
	private int empId;
	private String empName;
	private float empBasicSal;
	public Employee() {
		
	}
	public Employee(int empId, String empName, float empBasicSal) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empBasicSal = empBasicSal;
	} 
	
	
	@Override
   public String toString()
   {
	   return ("\nEmployee Id :"+empId +"\n"+"Employee Name:"+
                empName+"\n"+"Employee Basic Salary:"+empBasicSal+"\n");
   }
	public float calcEmpGrossSal()
	{
		return empBasicSal;
	}
	public  float CalcEmpAnnualSal()
	{
		return calcEmpGrossSal()*12;
	}
	
}
