package com.cg.customerapp.service;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class CustServiceMapImplTest {
	
	CustServiceMapImpl custMap;
	@Before
	public void Start()
	{
		custMap=new CustServiceMapImpl();
	}
	@Test
	public void testIsValidId() 
	{
		boolean flag=custMap.isValidId(1234);
		assertTrue(flag);	
	}
	@Test
	public void testIsValidIdContainMoreThanFourDigits() 
	{
		boolean flag=custMap.isValidId(123478654);
		assertFalse(flag);	
	}
	@Test
	public void testIsValidMailContainOnlyCharacter() 
	{
		boolean flag=custMap.isValidMail("praveen");
		assertFalse(flag);	
	}
	@Test
	public void testIsValidMail() 
	{
		boolean flag=custMap.isValidMail("praveenkumar212@gmail.com");
		assertTrue(flag);	
	}

	@Test
	public void testIsValidName() 
	{
		boolean flag=custMap.isValidName("praveen");
		assertFalse(flag);	
	}
	@Test
	public void testIsValidNameStartWithInt() 
	{
		boolean flag=custMap.isValidName("123praveen");
		assertFalse(flag);	
	}
	@Test
	public void testIsValidPhoneLessThanTen()
	{
		boolean flag=custMap.isValidPhone(12345678L);
		assertFalse(flag);
	}
	@Test
	public void testIsValidPhoneContainChar() 
	{
		boolean flag=custMap.isValidPhone(-987654l);
		assertFalse(flag);
	}

}
