package com.cg.customerapp.exception;

import static org.junit.Assert.*;

import org.junit.Test;

public class IdComponentTest {

	IdComponent ic = new IdComponent();
	@Test
	public void testIsValidId()
	{
	     boolean b=ic.isValidId(1002);
	    assertTrue(b);
	}

}
