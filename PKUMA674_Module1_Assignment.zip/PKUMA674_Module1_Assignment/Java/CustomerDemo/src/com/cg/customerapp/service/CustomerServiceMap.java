package com.cg.customerapp.service;

import java.util.Map;

import com.cg.customerapp.dto.CustomerDTO;

public interface CustomerServiceMap 
{
	public String addCustomer(int id,CustomerDTO cust);
	public String delCustomer(int id);
	public CustomerDTO modifyCustDetail(CustomerDTO custDto);
	public String delAllCust();
	public CustomerDTO custDetailByID(int id);
	public CustomerDTO allCustDetailByName(String name);
	public Map<Integer,CustomerDTO> getAllCust();
	public boolean isValidId(int id);
	public boolean isValidMail(String mail);
	public boolean isValidName(String name);
	public boolean isValidPhone(Long phNo);
}
