package com.cg.customerapp.exception;

import java.util.Set;

import com.cg.customeapp.dao.StaticDBMap;

public class IdComponent 
{
	public boolean isValidId(Integer id)
	{
		String idStr=""+id;
		boolean flag=false;
		if(idStr.matches("\\d {4}"))
		{
			flag=true;
		}
		Set<Integer> idSet=StaticDBMap.getCustMap().keySet();
	for(Integer tempId:idSet)
	{
		if(tempId==id)
		{
			flag= false;
		}
		else
		{
			flag=true;
		}	
	}
	return flag;
	}

}
