package com.cg.customerapp.exception;

public class NameComponent {

}
