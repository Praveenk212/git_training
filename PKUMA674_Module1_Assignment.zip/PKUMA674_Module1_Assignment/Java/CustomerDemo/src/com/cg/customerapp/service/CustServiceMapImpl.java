package com.cg.customerapp.service;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.customeapp.dao.CustomerDAO;
import com.cg.customeapp.dao.CustomerDAOImpl;
import com.cg.customeapp.dao.CustomerDAOMap;
import com.cg.customeapp.dao.CustomerDAOMapImpl;
import com.cg.customerapp.dto.CustomerDTO;
import com.cg.customerapp.exception.IdComponentTest;

public class CustServiceMapImpl implements CustomerServiceMap
{
	Matcher matcher=null;
	private static final Pattern ValidId=Pattern.compile("[1-9][0-9]{3}");
	private static final Pattern ValidMail=Pattern.compile("^[a-z 0-9]+@[a-z]+\\.[a-z]{2,6}$",Pattern.CASE_INSENSITIVE);
	private static final Pattern ValidName=Pattern.compile("[A-Z][a-z]*");
	private static final Pattern ValidPhone=Pattern.compile("[6-9][0-9]{9}");
	CustomerDAOMap custDAOMap=new CustomerDAOMapImpl();  
	@Override
	public String addCustomer(int id,CustomerDTO cust)
	{
		return custDAOMap.addCustomer(id,cust);
	}

	@Override
	public String delCustomer(int id) 
	{
		
		return custDAOMap.delCustomer(id);
	}

	@Override
	public CustomerDTO modifyCustDetail(CustomerDTO custDto)
	{
		
		return custDAOMap.modifyCustDetail(custDto);
		
	}

	@Override
	public String delAllCust()
	{
		
		return custDAOMap.delAllCust();
	}

	@Override
	public CustomerDTO custDetailByID(int id) {
		// TODO Auto-generated method stub
		return custDAOMap.custDetailByID(id);
	}

	@Override
	public CustomerDTO allCustDetailByName(String name) {
		
		return custDAOMap.allCustDetailByName(name);
	}

	@Override
	public Map<Integer, CustomerDTO> getAllCust() {
		
		return custDAOMap.getAllCust();
	}

	@Override
	public boolean isValidId(int id) {
		

		matcher =ValidId.matcher(String.valueOf(id));
		return matcher.matches();
	}

	@Override
	public boolean isValidMail(String mail) {
		matcher =ValidMail.matcher(mail);
		return matcher.matches();	
	}

	@Override
	public boolean isValidName(String name) {
		matcher =ValidName.matcher(name);
		return matcher.matches();	
	}

	@Override
	public boolean isValidPhone(Long phNo) {
		if(phNo>0)
		{
			matcher =ValidPhone.matcher(String.valueOf(phNo));
			return matcher.matches();	
		}
		else
		{
			return false;
		}
			
	}

	
	

}
