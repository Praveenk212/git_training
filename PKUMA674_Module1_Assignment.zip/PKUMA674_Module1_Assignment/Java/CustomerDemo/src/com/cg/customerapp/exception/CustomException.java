package com.cg.customerapp.exception;

public class CustomException extends RuntimeException
{
	public CustomException()
	{
		super();
	}
}
