package com.cg.customerapp.pl;
import java.util.*;

import com.cg.customerapp.dto.CustomerDTO;
import com.cg.customerapp.service.CustServiceImpl;
import com.cg.customerapp.service.CustomerService;
public class TestCusto {

	public static void main(String[] args) {
		CustomerService service=new CustServiceImpl();
		CustomerDTO custDto=new CustomerDTO();
		int id=0;
		String name="";
		Long phNo=0L;
		String addr="";
		String email="";
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			int choice;
			System.out.println("**************************************************************************************");
			System.out.println("1.Add a new Customer:");
			System.out.println("2.Delete Customer using id:");
			System.out.println("3.Modify customer detail based on id:");
			System.out.println("4.Delete all customer:");
			System.out.println("5.Customer Detail based on id:");
			System.out.println("6.Fetch Customer Detail based on name:");
			System.out.println("7.Fetch all Customer Detail:\n");
			System.out.println("Enter your choice or any othe number than choice to exit");
			choice=sc.nextInt();
			switch(choice)
			{
			
			case 1 :
				System.out.println("Enter Customer ID:");
				id=sc.nextInt();
				System.out.println("Enter Customer Name:");
				name=sc.next();
				System.out.println("Enter Customer Phone Number:");
				phNo=sc.nextLong();
				System.out.println("Enter Customer Address:");
				addr=sc.next();
				System.out.println("Enter Customer email:");
				email=sc.next();
				custDto=new CustomerDTO(id,name,phNo,addr,email);
				System.out.println("Customer with "+custDto.getCustName()+" Added SucessFully");
				service.addCustomer(custDto);
				break;
			case 2 :
				System.out.println("Enter the customer ID which you want to delete:");
				id=sc.nextInt();
				service.delCustomer(id);
				break;
				
			case 3 :
				System.out.println("Enter the customer ID which you want to modify:");
				id=sc.nextInt();
				service.modifyCustDetail(id);
				break;
			case 4 :
				service.delAllCust();
				break;
			case 5 :
				System.out.println("Enter the id whose detail you want:");
				id=sc.nextInt();
				custDto=service.custDetailByID(id);
				System.out.println(custDto);
				break;
			case 6 :
				System.out.println("Enter the name whose deatil you want:");
				name=sc.next();
				custDto=service.allCustDetailByName(name);
				System.out.println(custDto);
				break;
			case 7:
				System.out.println(service.getAllCust());
				break;
				
			default :
				System.exit(0);
			
			}
		}
		
	}

}
