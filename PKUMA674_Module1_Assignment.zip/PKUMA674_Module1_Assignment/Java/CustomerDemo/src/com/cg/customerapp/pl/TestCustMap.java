package com.cg.customerapp.pl;

import java.util.Collection;
import java.util.Scanner;
import java.util.stream.Stream;

import com.cg.customerapp.dto.CustomerDTO;
import com.cg.customerapp.service.CustServiceImpl;
import com.cg.customerapp.service.CustServiceMapImpl;
import com.cg.customerapp.service.CustomerService;
import com.cg.customerapp.service.CustomerServiceMap;

public class TestCustMap {

	public static void main(String[] args) 
	{
		CustomerServiceMap service=new CustServiceMapImpl();
		CustomerDTO custDto=new CustomerDTO();
		int id=0;
		String name="";
		Long phNo=0L;
		String addr="";
		String email="";
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			int choice;
			System.out.println("**************************************************************************************");
			System.out.println("1.Add a new Customer:");
			System.out.println("2.Delete Customer using id:");
			System.out.println("3.Modify customer detail based on id:");
			System.out.println("4.Delete all customer:");
			System.out.println("5.Customer Detail based on id:");
			System.out.println("6.Fetch Customer Detail based on name:");
			System.out.println("7.Fetch all Customer Detail:\n");
			System.out.println("Enter your choice or any othe number than choice to exit");
			choice=sc.nextInt();
			switch(choice)
			{
			
			case 1 :
				System.out.println("Enter Customer ID:");
				id=sc.nextInt();
				while(!service.isValidId(id))
				{
				System.out.println("Enter Valid Id i.e only of 4 digit");
				id=sc.nextInt();	
				}
				sc.nextLine();
				System.out.println("Enter Customer Name:");
				name=sc.nextLine();
				while(!service.isValidName(name))
				{
				System.out.println("Enter Valid Name First Letter should be Captital");
				name=sc.nextLine();	
				}
				System.out.println("Enter Customer Phone Number:");
				phNo=sc.nextLong();
				while(!service.isValidPhone(phNo))
				{
				System.out.println("Enter Valid Phone Number");
				phNo=sc.nextLong();	
				}
				sc.nextLine();
				System.out.println("Enter Customer Address:");
				addr=sc.nextLine();
				System.out.println("Enter Customer email:");
				email=sc.next();
				while(!service.isValidMail(email))
				{
				System.out.println("Enter Valid email");
				email=sc.next();	
				}
				custDto=new CustomerDTO(id,name,phNo,addr,email);
				System.out.println("Customer with "+custDto.getCustName()+" Added SucessFully");
				System.out.println(service.addCustomer(id,custDto));
				break;
			case 2 :
				System.out.println("Enter the customer ID which you want to delete:");
				id=sc.nextInt();
				System.out.println(service.delCustomer(id));
				break;
				
			case 3 :
				System.out.println("Enter the detail you want to modify:");
				System.out.println("Enter Customer ID you want to modify:");
				id=sc.nextInt();
				while(!service.isValidId(id))
				{
				System.out.println("Enter Valid Id i.e only of 4 digit");
				id=sc.nextInt();	
				}
				sc.nextLine();
				System.out.println("Enter Customer Name or press enter if you dont want to modify:");
				name=sc.nextLine();
				if(name.length()>0)
				{
					while(!service.isValidName(name))
					{
					System.out.println("Enter Valid Name First Letter should be Captital");
					name=sc.nextLine();	
					}
				}
				else
				{
					name=name;
				}
				System.out.println("Enter Customer Phone Number or press enter if you dont want to modify:");
				String tempstr=sc.nextLine();
				phNo=Long.parseLong(tempstr.equals("")?"0":tempstr);
				if(phNo>0)
				{
					while(!service.isValidPhone(phNo))
					{
					System.out.println("Enter Valid Phone Number");
					phNo=sc.nextLong();	
					}
				}
				System.out.println("Enter Customer Address or press enter if you dont want to modify:");
				addr=sc.nextLine();
				System.out.println("Enter Customer email or press enter if you dont want to modify:");
				email=sc.nextLine();
				if(email.length()>0)
				{
					while(!service.isValidMail(email))
					{
					System.out.println("Enter Valid email");
					email=sc.next();	
					}
				}
				else
				{
					email=email;
				}
				custDto=new CustomerDTO(id,name,phNo,addr,email);
				service.modifyCustDetail(custDto);
				break;
			case 4 :
				service.delAllCust();
				break;
			case 5 :
				System.out.println("Enter the id whose detail you want:");
				id=sc.nextInt();
				custDto=service.custDetailByID(id);
				System.out.println(custDto);
				break;
			case 6 :
				System.out.println("Enter the name whose deatil you want:");
				name=sc.next();
				custDto=service.allCustDetailByName(name);
				System.out.println(custDto);
				break;
			case 7:
				Collection<CustomerDTO> cusList=service.getAllCust().values();
				cusList.stream().filter(
						cust->cust.getCustName().length()>6).map(cust->cust.getCustName().toUpperCase()).forEach(System.out::println);
				//System.out.println(service.getAllCust());
				break;
				
			default :
				System.exit(0);
			
			}
		}
		

	}

}
