package com.cg.customerapp.service;
import java.util.*;

import com.cg.customeapp.dao.CustomerDAO;
import com.cg.customeapp.dao.CustomerDAOImpl;
import com.cg.customerapp.dto.CustomerDTO;
public class CustServiceImpl  implements CustomerService
{
    CustomerDAO custDAO=new CustomerDAOImpl();
	@Override
	public void addCustomer(CustomerDTO cust)
	{
		custDAO.addCustomer(cust);
	}

	@Override
	public void delCustomer(int id)
	{
		
		custDAO.delCustomer(id);
	}

	@Override
	public void modifyCustDetail(int id) 
	{
		custDAO.modifyCustDetail(id);
		
	}

	@Override
	public void delAllCust()
	{
		custDAO.delAllCust();
		
	}

	@Override
	public CustomerDTO custDetailByID(int id) 
	{
		return custDAO.custDetailByID(id);
		
	}

	@Override
	public CustomerDTO allCustDetailByName(String name) 
	{
		// TODO Auto-generated method stub
		return custDAO.allCustDetailByName(name);
	}

	@Override
	public ArrayList<CustomerDTO> getAllCust() {
		// TODO Auto-generated method stub
		return custDAO.getAllCust();
	}
	
	

}
