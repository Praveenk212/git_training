package com.cg.customerapp.exception;

public class MailComponent {

}
