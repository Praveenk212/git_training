package com.cg.customeapp.dao;

import java.util.ArrayList;

import com.cg.customerapp.dto.CustomerDTO;

public interface CustomerDAO {
	
	public void addCustomer(CustomerDTO cust);
	public void delCustomer(int id);
	public void modifyCustDetail(int id);
	public void delAllCust();
	public CustomerDTO custDetailByID(int id);
	public CustomerDTO allCustDetailByName(String name);
	public ArrayList<CustomerDTO> getAllCust();

}
