package com.cg.customeapp.dao;

import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.customerapp.dto.CustomerDTO;

public class CustomerDAOImpl implements CustomerDAO
{
	Logger mylogger=Logger.getRootLogger();
	public CustomerDAOImpl() {
		super();
		PropertyConfigurator.configure("resource/custlog.properties");
	}
	//ArrayList<CustomerDTO> custAL=new ArrayList<CustomerDTO>();
	@Override
	public void addCustomer(CustomerDTO cust) 
	{
		mylogger.info("Added Sucessfully");
		(staticDB.getCustAL()).add(cust);
		
		
	}

	@Override
	public void delCustomer(int id) 
	{
		int remIndex = 0;
		int flag=0;
		for(int i=0;i<staticDB.getCustAL().size();i++)
		{
			if(((staticDB.getCustAL()).get(i).getCustId())==id)
			{
				remIndex=i;
				flag=1;
			}
		}
		
		if(flag==0)
		{
			System.out.println("Customer with "+id+" Not Found");
		}
		else
		{
			staticDB.getCustAL().remove(remIndex);
			System.out.println("Customer with "+id+" Removed SucessFully");
		} 
		
	}

	

	@Override
	public void modifyCustDetail(int id) 
	{
		int remIndex = 0;
		int flag=0;
		for(int i=0;i<staticDB.getCustAL().size();i++)
		{
			if(((staticDB.getCustAL()).get(i).getCustId())==id)
			{
				remIndex=i;
				flag=1;
			}
		}
		
		if(flag==0)
		{
			System.out.println("Customer with "+id+" Not Found");
		}
		else
		{
			staticDB.getCustAL();
		} 
		
	}

	@Override
	public void delAllCust()
	{
		staticDB.getCustAL().removeAll(staticDB.getCustAL());
		System.out.println("All the data were deleted");
		
	}

	@Override
	public CustomerDTO custDetailByID(int id) {
		CustomerDTO tempCust=new CustomerDTO();
		int searchIndex = 0;
		int flag=0;
		for(int i=0;i<staticDB.getCustAL().size();i++)
		{
			if(staticDB.getCustAL().get(i).getCustId()==id)
			{
				searchIndex=i;
				flag=1;
			}
		}
		
		if(flag==0)
		{
			System.out.println("Customer with "+id+" Not Found");
		}
		else
		{
			tempCust=staticDB.getCustAL().get(searchIndex);
		}
		return tempCust;
	}

	@Override
	public CustomerDTO allCustDetailByName(String name) {
		
		CustomerDTO tempCust=new CustomerDTO();
		int searchIndex = 0;
		int flag=0;
		for(int i=0;i<staticDB.getCustAL().size();i++)
		{
			if(staticDB.getCustAL().get(i).getCustName().equalsIgnoreCase(name));
			{
				searchIndex=i;
				flag=1;
			}
		}
		
		if(flag==0)
		{
			System.out.println("Customer with "+name+" Not Found");
		}
		else
		{
			tempCust=staticDB.getCustAL().get(searchIndex);
		}
		return tempCust;
	}

	@Override
	public ArrayList<CustomerDTO> getAllCust()
	{
		ArrayList<CustomerDTO> custList=staticDB.getCustAL();
		return custList;
		
	}

}
