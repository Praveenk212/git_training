package com.cg.customeapp.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.cg.customerapp.dto.CustomerDTO;

public class StaticDBMap 
{
	
	static Map<Integer,CustomerDTO> custMap=new HashMap<Integer,CustomerDTO>();
	
	public static Map<Integer, CustomerDTO> getCustMap()
	{
		return custMap;
	}

	public static void setCustMap(Map<Integer, CustomerDTO> custMap) 
	{
		StaticDBMap.custMap = custMap;
	}

	
	
	

	static
	{
		custMap.put(1002,new CustomerDTO(1002,"Praveen",9087654324L,"Pune","pkumar@gmail.com"));
		custMap.put(1003,new CustomerDTO(1003,"PKumar",9087654326L,"Pune","pku@gmail.com"));
		custMap.put(1004,new CustomerDTO(1004,"PKR",9087654328L,"Pune","pkma@gmail.com"));
		custMap.put(1005,new CustomerDTO(1005,"PKUM",9087654322L,"Pune","pkumarroy@gmail.com"));
	}
	

}
