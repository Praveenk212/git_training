package com.cg.customeapp.dao;

import java.util.ArrayList;

import com.cg.customerapp.dto.CustomerDTO;

public class staticDB {
	
	private static ArrayList<CustomerDTO> custAL=new ArrayList<CustomerDTO>();
	
	public static ArrayList<CustomerDTO> getCustAL() {
		return custAL;
	}

	public static void setCustAL(ArrayList<CustomerDTO> custAL) {
		staticDB.custAL = custAL;
	}

	static
	{
		custAL.add(new CustomerDTO(1002,"Praveen",9087654324L,"Pune","pkumar@gmail.com"));
		custAL.add(new CustomerDTO(1003,"PKumar",9087654326L,"Pune","pku@gmail.com"));
		custAL.add(new CustomerDTO(1004,"PKR",9087654328L,"Pune","pkma@gmail.com"));
		custAL.add(new CustomerDTO(1005,"PKUM",9087654322L,"Pune","pkumarroy@gmail.com"));
	}
	

}
