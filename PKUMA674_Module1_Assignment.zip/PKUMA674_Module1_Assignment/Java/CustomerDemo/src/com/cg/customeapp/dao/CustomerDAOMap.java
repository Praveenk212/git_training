package com.cg.customeapp.dao;

import java.util.ArrayList;
import java.util.Map;

import com.cg.customerapp.dto.CustomerDTO;

public interface CustomerDAOMap 
{
	public String addCustomer(int id,CustomerDTO cust);
	public String delCustomer(int id);
	public CustomerDTO modifyCustDetail(CustomerDTO custDto);
	public String delAllCust();
	public CustomerDTO custDetailByID(int id);
	public CustomerDTO allCustDetailByName(String name);
	public Map<Integer,CustomerDTO> getAllCust();

	

}
