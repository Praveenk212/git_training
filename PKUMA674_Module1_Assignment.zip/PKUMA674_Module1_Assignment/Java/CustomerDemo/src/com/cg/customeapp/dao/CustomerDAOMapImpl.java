package com.cg.customeapp.dao;

import java.util.ArrayList;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.customerapp.dto.CustomerDTO;
import com.cg.customerapp.exception.CustomException;

public class CustomerDAOMapImpl implements CustomerDAOMap
{
	CustomerDTO tempCust=null;
	
	Logger mylogger=Logger.getRootLogger();
	public CustomerDAOMapImpl() {
		super();
		PropertyConfigurator.configure("resource/custlog.properties");
	}

	
	@Override
	public String addCustomer(int id,CustomerDTO cust) 
	{
		(StaticDBMap.getCustMap()).put(id,cust);
		mylogger.info("Customer Added to map");
		return "Added Sucessfully";
	}
	@Override
	public String delCustomer(int id) 
	{
		if((StaticDBMap.getCustMap()).containsKey(id))
		{
			(StaticDBMap.getCustMap()).remove(id);
			mylogger.info("Customer Deleted SucessFully");
			return "Deleted SucessFully";
		}
		else
		{
			mylogger.info("Not Found The id for Deletion");
			return "Not found in the Map";
		}
		
	}
	
	@Override
	public CustomerDTO modifyCustDetail(CustomerDTO custDto) 
	{
		tempCust=new CustomerDTO();
		if((StaticDBMap.getCustMap()).containsKey(custDto.getCustId()))
		{
			tempCust=(StaticDBMap.getCustMap()).get(custDto.getCustId());
			mylogger.info("CustomerDto object returned according to id");
		}
		else
		{
			mylogger.info("CustomerDto object not found as per id");
			throw new CustomException();
		}
		if(custDto.getCustName().length()>0);
		{
			tempCust.setCustName(custDto.getCustName());
		}
		if(custDto.getAddress().length()>0);
		{
			tempCust.setAddress(custDto.getAddress());
		}
		if(custDto.getEmail().length()>0);
		{
			tempCust.setEmail(custDto.getEmail());
		}
		if(custDto.getPhoneNo()>0);
		{
			tempCust.setPhoneNo(custDto.getPhoneNo());
		}
		return tempCust;
	}

	@Override
	public String delAllCust()
	{
		(StaticDBMap.getCustMap()).clear();;
		mylogger.info("All Customer Deleted SucessFully");
		return "All the data were deleted";	
	}

	@Override
	public CustomerDTO custDetailByID(int id) 
	{
		tempCust=new CustomerDTO();
		if((StaticDBMap.getCustMap()).containsKey(id))
		{
			tempCust=(StaticDBMap.getCustMap()).get(id);
			mylogger.info("CustomerDto object returned according to id");
		}
		else
		{
			mylogger.info("CustomerDto object not found as per id");
			throw new CustomException();
		}
		return tempCust;
	}
	
	@Override
	public CustomerDTO allCustDetailByName(String name) 
	{
		for(CustomerDTO custDto:StaticDBMap.getCustMap().values())
		{
			if(custDto.getCustName().equals(name))
			{
				mylogger.info("CustomerDto object returned according to name");
				return custDto;
			}
			else
			{
				mylogger.info("CustomerDto object not found as per name");
				throw new CustomException();
			}
		}
		return null;
	}

	@Override
	public Map<Integer,CustomerDTO> getAllCust()
	{
		mylogger.info("Complete Map Returned");
		return (StaticDBMap.getCustMap());
		
	}
	

}
