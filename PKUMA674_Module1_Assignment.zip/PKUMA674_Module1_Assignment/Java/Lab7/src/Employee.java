import java.util.Collection;
import java.util.Comparator;
import java.util.Map.Entry;

public class Employee {
	private int empId;
	private String empName;
	private float empBasicSal;
	public Employee() {
		
	}
	public Employee(int empId, String empName, float empBasicSal) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empBasicSal = empBasicSal;
	} 
	
	@Override
   public String toString()
   {
	   return ("\nEmployee Id :"+empId +"\n"+"Employee Name:"+
                empName+"\n"+"Employee Basic Salary:"+empBasicSal+"\n");
   }
	public float calcEmpGrossSal()
	{
		return empBasicSal;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getEmpBasicSal() {
		return empBasicSal;
	}
	public void setEmpBasicSal(float empBasicSal) {
		this.empBasicSal = empBasicSal;
	}
	
}
