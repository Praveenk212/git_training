import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map.Entry;

public class TestEmpConcurrentHashMap {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		ConcurrentHashMap<Long,Employee> empConcurrentHashMap=new ConcurrentHashMap
				<Long,Employee>();
		Employee e1=new Employee(1002,"Praveen",76777.98F);
		Employee e2=new Employee(1003,"PK",77997.98F);
		Employee e3=new Employee(1004,"RAHUL",987777.98F);
		Employee e4=new Employee(1002,"Praveen",76777.98F);
		empConcurrentHashMap.put(9987654321L, e1);
		empConcurrentHashMap.put(9987654324L, e2);
		empConcurrentHashMap.put(9987654326L, e3);
		empConcurrentHashMap.put(9987654328L, e4);
		Employee tempEmp=null;
		 Set<Entry<Long, Employee>> empEntrySet=
					empConcurrentHashMap.entrySet();
		 String tempName="";
		while(true)
		{
			int choice ;
			System.out.println("Enter your Choice:");
			System.out.println("To Exit Enter any other number than choice:");
			System.out.println("1.Add :");
			System.out.println("2.Search By Name:");
			System.out.println("3.Delete:");
			System.out.println("4.Display:");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Enter Id");
				int id=sc.nextInt();
				System.out.println("Enter Name");
				String name=sc.next();
				System.out.println("Enter Salary");
				float sal=sc.nextInt();
				System.out.println("Enter Phone Number:");
				Long phNo=sc.nextLong();
				Employee e=new Employee(id,name,sal);
				empConcurrentHashMap.put(phNo, e);
				System.out.println("Added Sucessfully");
				break;
			case 2:
				System.out.println
				("Enter the name Whose Mobile no. You want to Search:");
				tempName=sc.next();
				int flag=0;
				for(Entry ent:empEntrySet)
				{
					tempEmp=(Employee)ent.getValue();
					if(tempEmp.getEmpName().equalsIgnoreCase(tempName))
					{
						System.out.println(ent.getKey());
						flag=1;
					}
				 }
				if(flag==0)
				{
					System.out.println("Employee with name"+ tempName+" Not found");
				}
				break;
			case 3:
				System.out.println
				("Enter the name You want to Delete:");
				tempName=sc.next();
				int tempFlag=0;
				for(Entry ent:empEntrySet)
				{
					tempEmp=(Employee)ent.getValue();
					if(tempEmp.getEmpName().equalsIgnoreCase(tempName))
					{
						empConcurrentHashMap.remove(ent.getKey());
						tempFlag=1;
					}
				 }
				if(tempFlag==0)
				{
					System.out.println("Employee with name"+ tempName+" Not found");
				}
				else
				{
					System.out.println("Employee with name "+ tempName+" Deleted");	
				}
				break;
			case 4:
				System.out.println(empConcurrentHashMap);
				break;
			default:
				System.out.println("Exited");
				System.exit(0);
			}
		}
	
	}

}
