import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Map.Entry;

public class TestEmpHashMap implements Comparator {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		HashMap<Long,Employee> empHashMap=new HashMap
				<Long,Employee>();
		Employee e1=new Employee(1002,"Praveen",76777.98F);
		Employee e2=new Employee(1003,"PK",77997.98F);
		Employee e3=new Employee(1004,"RAHUL",987777.98F);
		Employee e4=new Employee(1002,"Praveen",76777.98F);
		empHashMap.put(9987654321L, e1);
		empHashMap.put(9987654324L, e2);
		empHashMap.put(9987654326L, e3);
		empHashMap.put(9987654328L, e4);
		Employee tempEmp=null;
		 Set<Entry<Long, Employee>> empEntrySet=
					empHashMap.entrySet();
		 String tempName="";
		while(true)
		{
			int choice ;
			System.out.println("Enter your Choice:");
			System.out.println("To Exit Enter any other number than choice:");
			System.out.println("1.Add :");
			System.out.println("2.Search By Name:");
			System.out.println("3.Delete:");
			System.out.println("4.Display:");
			System.out.println("5.Sort by Id:");
			
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Enter Id");
				int id=sc.nextInt();
				System.out.println("Enter Name");
				String name=sc.next();
				System.out.println("Enter Salary");
				float sal=sc.nextInt();
				System.out.println("Enter Phone Number:");
				Long phNo=sc.nextLong();
				Employee e=new Employee(id,name,sal);
				empHashMap.put(phNo, e);
				System.out.println("Added Sucessfully");
				break;
			case 2:
				System.out.println
				("Enter the name Whose Mobile no. You want to Search:");
				tempName=sc.next();
				int flag=0;
				for(Entry ent:empEntrySet)
				{
					tempEmp=(Employee)ent.getValue();
					if(tempEmp.getEmpName().equalsIgnoreCase(tempName))
					{
						System.out.println(ent.getKey());
						flag=1;
					}
				 }
				if(flag==0)
				{
					System.out.println("Employee with name"+ tempName+" Not found");
				}
				break;
			case 3:
				System.out.println
				("Enter the name You want to Delete:");
				tempName=sc.next();
				ArrayList<Long> key=new ArrayList<Long>();
				for(Entry ent:empEntrySet)
				{
					tempEmp=(Employee)ent.getValue();
					if(tempEmp.getEmpName().equalsIgnoreCase(tempName))
					{
						key.add((Long)ent.getKey());
					}
				 }
				
				for(int i=0;i<key.size();i++)
				{
					empHashMap.remove(key.get(i));
				}
				if(key.size()==0)
				{
					System.out.println("Employee with name "+tempName+" Not found");
				}
				else
				{
					System.out.println("Employee with name "+ tempName+" Deleted");
				}
				break;
			case 4:
				System.out.println(empHashMap);
				break;
			case 5:
				TreeSet<Employee> empTreeSet=new TreeSet<Employee>(new TestEmpHashMap());
				for(Entry ent:empEntrySet)
				{
					empTreeSet.add((Employee) ent.getValue());
				}
				System.out.println(empTreeSet);
				TreeMap<Long,Employee> empTreeMap=new TreeMap<Long,Employee>(empHashMap);
				System.out.println(empTreeMap);
				break;
			default:
				System.out.println("Exited");
				System.exit(0);
			}
		}
	
	}
	@Override
	public int compare(Object o1, Object o2) {
		if(((Employee) o1).getEmpId()<((Employee) o2).getEmpId())
		{
			return -1;
		}
		else
		{
			return +1;
		}
	}

}
