
public class abc
{
	public static long main(String [] args)
	{
		
		System.out.println("hello");
		return 10l;
	}
}