
class Calculator
{
	public void add(byte a,byte b)
	{
		System.out.println("Addition of bytes :"+(a+b));
	}
	public void add(int a,int b)
	{
		System.out.println("Addition of int :"+(a+b));
	}
	public void add(Integer a,Integer b)
	{
		System.out.println("Addition of Integer :"+(a+b));
	}
}
public class TestCalculatorDemo {

	public static void main(String[] args) {
		Calculator c=new Calculator();
		byte b=(byte)8959;
		System.out.println(b);
		
	}

}
