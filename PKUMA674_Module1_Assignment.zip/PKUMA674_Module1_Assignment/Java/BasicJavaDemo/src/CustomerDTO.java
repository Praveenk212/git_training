
public class CustomerDTO {
	
	
	private int custId;
	private String custName;
	private Long phoneNo;
	private String address;
	private String email;
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	
	
	public Long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public CustomerDTO() {
		super();
	}

	public CustomerDTO(int custId, String custName, Long phoneNo, String address, String email) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.phoneNo = phoneNo;
		this.address = address;
		this.email = email;
	}
	@Override
	public String toString() {
		return "CustomerDTO [custId=" + custId + ", custName=" + custName + ", phoneNo=" + phoneNo + ", address="
				+ address + ", email=" + email + "]";
	}
	

	
}
