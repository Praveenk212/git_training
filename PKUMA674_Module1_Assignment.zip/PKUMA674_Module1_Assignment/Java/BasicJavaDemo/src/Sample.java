import java.util.Set;
import java.util.TreeSet;
import static java.lang.Math.*;
public class Sample {

	public static void main(String[] args) 
	{
		System.out.println(ulp(10));
	}
	
}
