import java.util.Scanner;

public class TestEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of Employee:");
		int number=sc.nextInt();
		EmployeeDetail e[]=new EmployeeDetail[number];
        for(int i=0;i<number;i++)
        {
        	System.out.println("Enter Detail of Employee "+(i+1));
        	System.out.println("EmpID:");
        	int EmpId=sc.nextInt();
        	sc.nextLine();
        	System.out.println("Name:");
        	String Name=sc.nextLine();
        	System.out.println("Salary:");
        	float Salary=sc.nextFloat();
        	sc.nextLine();
        	System.out.println("Gender in M/F/O:");
        	char Gender=sc.next().toCharArray()[0];
        	sc.nextLine();
        	System.out.println("Age:");
        	int Age=sc.nextInt();
        	sc.nextLine();
        	e[i]=new EmployeeDetail(EmpId,Name,Salary,Gender,Age);
        }
        
        for(int i=0;i<number;i++)
        {
        	
        System.out.println("Detail of Employee "+ (i+1)+" :"+e[i]);
        }
	}

}
