
public class EmployeeDetail {
	int EmpId;
	String Name;
	float Salary;
	char Gender;
	int Age;
	public EmployeeDetail(int age) {
		super();
		Age = age;
	}
	public EmployeeDetail() {
		super();
		EmpId = 0;
		Name = "";
		Salary = 0;
		Gender = ' ';
		Age=0;
	} 
	public EmployeeDetail(int empId, String name, float salary, char gender,int age) {
		super();
		EmpId = empId;
		Name = name;
		Salary = salary;
		Gender = gender;
		Age =age;
	} 
	public static float CalcAnnualSal(float salary2)
	{
		float AnnualSal;
		AnnualSal=salary2*12;
		return AnnualSal;
	}
   public String toString()
   {
	   return ("\nEmployee Id :"+EmpId +"\n"+"Employee Name:"+
                Name+"\n"+"Employee Salary:"+Salary+"\n"+"Gender :"
                +Gender+"\n"+"Employee Age:"+Age+"\n"+"Annual Salary:"+
                CalcAnnualSal(Salary));
   }
}
