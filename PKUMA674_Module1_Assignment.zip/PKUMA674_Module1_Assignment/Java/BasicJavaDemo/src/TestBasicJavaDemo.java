

public class TestBasicJavaDemo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      System.out.println("Welcome Praveen Welcome");
      for(int i=0;i<args.length;i++)
      {
    	  System.out.println(args[i]);
      }
      WishMe m=new WishMe();
      m.wish();
	}
	public static int main(int g) {
		// TODO Auto-generated method stub
      System.out.println("Welcome Praveen Welcome");
	return 0;
	}

}
class WishMe
{
	public void wish()
	{
	System.out.println("Happy Holi");
	}

}
