
public class TestDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date suhasDOJ=new Date();
		Date amanDOJ=new Date();
		suhasDOJ.initDate();
		amanDOJ.setDate(9,01,2020);
		System.out.println("Suhas DOJ : "+ 
		                  suhasDOJ.dispDate());
		System.out.println("Aman DOJ : "+ 
                amanDOJ.dispDate());
	}

}
