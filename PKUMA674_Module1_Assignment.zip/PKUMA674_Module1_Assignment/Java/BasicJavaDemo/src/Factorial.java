
public class Factorial {
	static int CalcFact(int Number)
	  { int fact=1;
		  for(int i=1;i<=Number;i++)
	       {
	    	   fact=fact*i;
	       }  
		  return fact;
	  }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int no=Integer.parseInt(args[0]);
		int Fnumber=CalcFact(no);
	  
       System.out.println("Factorial of Number ="+Fnumber);
		
	}

}
