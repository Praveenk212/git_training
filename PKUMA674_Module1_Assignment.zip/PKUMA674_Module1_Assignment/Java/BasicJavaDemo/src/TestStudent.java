
public class TestStudent {

	public static void main(String[] args) {
		Student st1=new Student();
		st1.setRollNo(9000);
		st1.setStuName("pK");
		System.out.println(st1.getStuName());

	}

}
