
public interface Service {

	public void addCustomer();
	public void delCustomer(int id);
	public void modifyCustDetail(int id);
	public void delAllCust();
	public CustomerDTO allCustDetailByID(int id);
	public CustomerDTO allCustDetailByName(String name);
	
}
