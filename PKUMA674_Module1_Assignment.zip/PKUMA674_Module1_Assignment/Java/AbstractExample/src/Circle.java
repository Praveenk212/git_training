import static java.lang.Math.*;
public class Circle extends Shape  implements Printable{
	int radius;
	
	@Override
	public String print()
	{
		return "Radius :"+radius;
	}
	public Circle()
	{
		
	}
	public Circle(String type) {
		super();
		this.type = type;
	}

	public Circle(int radius) {
		super("Circle");
		this.radius = radius;
	}
	@Override
	public float calcArea()
	{
		return (float)(PI*radius*radius);
	}
	@Override
	public float calcPerimeter()
	{
		return (float)(2*PI*radius);
		
	}

}
