
public interface Printable {
	int  fixVlaue=100;
	String print();

}
