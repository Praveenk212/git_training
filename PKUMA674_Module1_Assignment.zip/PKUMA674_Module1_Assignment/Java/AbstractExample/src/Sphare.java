import static java.lang.Math.PI;

public class Sphare extends Circle {
	
	int radius;
	public Sphare()
	{
		
	}
	

	public Sphare(int radius) {
		super("Sphare");
		this.radius = radius;
	}
	@Override
	public float calcArea()
	{
		return (float)(PI*radius*radius);
	}
	@Override
	public float calcPerimeter()
	{
		return (float)(2*PI*radius);
		
	}
	public float calcVolume()
	{
		return (float)((4/3)*PI*radius*radius*radius);
		
	}

}
