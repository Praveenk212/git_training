
public abstract class Shape {
	
	String type;
	
	public Shape() {
	}
	public Shape(String type) {
		super();
		this.type = type;
	}
	public void drawShape()
	{
		System.out.println("Draw "+type+"in red colour");
	}
	public abstract float calcArea();
	public abstract float calcPerimeter();

}
