import java.io.*;


public class ReadOperationDemo implements Serializable{

	public static void main(String[] args) throws IOException {
		FileOutputStream fs = null;
		FileInputStream fi = null;
		File f=new File("C://Data//praveen.txt");
		System.out.println(f.getAbsolutePath());
//		try
//		{
//			fs=new FileOutputStream
//					("C://Data//pk.txt",true);
//			fi=new FileInputStream("C://Data//praveen.txt");
//		}
//		catch(Exception e)
//		{
//		  System.out.println(e);
//		}
//		char ch=' ';
//		while(ch!=(char)fi.read())
//		{
//			System.out.println(ch);
//		}
//     fs.close();
//     fi.close();
	}

}
