import java.util.Scanner;

class Calculator
{
	int num1;
	int num2;
	int result;
	public int divide()
	{
		try
		{
		result=num1/num2;
		}
		catch(ArithmeticException ae)
		
		{
			System.out.println("Check the number you are entering"+ae.getMessage());
		}
		catch(Exception e)
		{
			System.out.println("Generic Exception:"+e.getMessage());
		}
		return result;
	}
	public Calculator() {
		super();
	}
	public Calculator(int num1, int num2) {
		super();
		this.num1 = num1;
		this.num2 = num2;
	}
	@Override
	public String toString() {
		return "Calculator [num1=" + num1 + ", num2=" + num2 + ", result=" + result + "]";
	}
}
public class TestCaluclatorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner s=new Scanner(System.in);
		System.out.println("Enter Number 1:");
		int n1=s.nextInt();
		System.out.println("Enter Number 2:");
		int n2=s.nextInt();
		Calculator cal=new Calculator(n1,n2);
		System.out.println("Result of division:"+cal.divide());
		//System.out.println(cal);

	}

}
