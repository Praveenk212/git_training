import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestPatternDemo {

	public static void main(String[] args) {
		
		String name=null;
		String namePattern="[A-Z][a-z]{8,20}";
		
		String input="Shop,mop,Hopping,Chopping";
		Pattern pattern=Pattern.compile("hop");
		Matcher matcher=pattern.matcher(input);
		System.out.println(matcher.matches());
		while(matcher.find())
		{
			System.out.println(matcher.group()+":"+matcher.start()+" to "
					           +matcher.end());
		}
		
		try(Scanner sc=new Scanner(System.in))
		{
		 System.out.println("Enter Your Name:");
		 name=sc.next();
		 if(Pattern.matches(namePattern, name))
		 {
			 System.out.println("Valid Name");
		 }
		 else
		 {
			 System.out.println("invalid Pattern");
		 }
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
