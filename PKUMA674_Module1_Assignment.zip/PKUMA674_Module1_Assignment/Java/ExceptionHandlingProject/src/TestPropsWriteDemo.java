import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

public class TestPropsWriteDemo {

	public static void main(String[] args) 
	{
		try 
		{
			FileWriter fw=new FileWriter("dbInfo.Properties");
			Properties dbProps=new Properties();
			dbProps.setProperty("dbUserName", "System");
			dbProps.setProperty("dbPwd", "root");
			dbProps.setProperty("dbType", "Oracle");
			dbProps.store(fw, "This Is DB info");
			System.out.println("Created");
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}

	}

}
