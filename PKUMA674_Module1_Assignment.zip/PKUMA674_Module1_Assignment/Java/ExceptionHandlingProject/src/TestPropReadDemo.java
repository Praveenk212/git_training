import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Enumeration;
import java.util.Properties;

public class TestPropReadDemo {

	public static void main(String[] args) {
		FileReader fr=null;
		Properties props=null;
	try 
	{
		fr=new FileReader("userinfo.properties");
		props=new Properties();
		props.load(fr);
		System.out.println("Number of Properties:"+props.size());
		
//		for(int i=0;i<props.size();i++)
//		{
//			System.out.println("Prop Name:"+props.entrySet());
//		}
		
		
		Enumeration en=props.keys();
		while(en.hasMoreElements())
		{
			String key=(String)en.nextElement();
			System.out.println("key: "+key+" value : "+props.getProperty(key));
		}
		
	 } 
	catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	}

}
