package com.cg.customeapp.dao;

import java.beans.Statement;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import com.cg.mobileapp.dto.CustomerDTO;
import com.cg.mobileapp.exception.NoMobileException;
import com.cg.customeapp.dao.DbConnectionSetUp;

public class MobileDAOImpl implements MobileDAO
{
	
	Connection con;
	PreparedStatement pst;
	Statement st;
	ResultSet rs;
	int delCount=0;
    SimpleDateFormat sdf=new SimpleDateFormat("dd/mm/yyyy");
    String StrDate="";
    int count=0;
	@Override
	public String purchaseMobile(int mobileid,CustomerDTO cust) 
	{
		 try
		    {
				con=DbConnectionSetUp.getInstance().getConnection();
				//con.setAutoCommit(false);
				pst=con.prepareStatement("Select * from mobiles"
						+ " where mobileid=?");
				pst.setInt(1, mobileid);
				rs=pst.executeQuery();
				int quantity=0;
				while(rs.next())
				{
					quantity=rs.getInt(4);
				}
				if(quantity>0)
				{
					pst=con.prepareStatement("update mobiles set quantity=quantity-1"
							+ " where mobileid=?");
					pst.setInt(1, mobileid);
					delCount=pst.executeUpdate();
					pst=con.prepareStatement("insert into purchasedetails values"
							+ "(purchase_id.nextVal,?,?,?,?,?)");
					
					pst.setString(1,cust.getCustName());
					pst.setString(2,cust.getEmail());
					pst.setLong(3, cust.getPhoneNo());

					java.util.Date date=new java.util.Date();
					java.sql.Date sqlDate=new java.sql.Date(date.getTime());
					pst.setDate(4, sqlDate);
					pst.setInt(5, mobileid);
					count=pst.executeUpdate();
				}
				else
				{
					throw new NoMobileException();
				}
				
			} 
		    catch (SQLException e) 
		    {
			
			} 
		    catch (IOException e) 
		    {
		    	
			}
		 if(count>0)
		 {
			 return "Quantity reduced in mobiles Table and Purchase detail were inserted";
		 }
		 else
		 {
			 return "Mobile id given were wrong";
		 }
	}
	
	@Override
	public ResultSet allMobileDetail() 
	{
	    try
	    {
			con=DbConnectionSetUp.getInstance().getConnection();
			pst=con.prepareStatement("Select * from mobiles");
			rs=pst.executeQuery();
		} 
	    catch (SQLException e) 
	    {
		
		} 
	    catch (IOException e) 
	    {
		
		}
		return rs;
	}


	@Override
	public String delMobile(int mobid) 
	{
	    
	    try
	    {
			con=DbConnectionSetUp.getInstance().getConnection();
			con.setAutoCommit(false);
			pst=con.prepareStatement("Delete from mobiles where mobileid=?");
			pst.setInt(1, mobid);
			delCount=pst.executeUpdate();
		} 
	    catch (SQLException e) 
	    {
		
		} 
	    catch (IOException e) 
	    {
			
		}
		if(delCount>0)
		{
			return "Deleted";
		}
		else
		{
			return "Not Found";
		}
	}

	@Override
	public ResultSet getAllMobileOfRange(double startPrice,double EndPrice) 
	{
		  try
		    {
				con=DbConnectionSetUp.getInstance().getConnection();
				pst=con.prepareStatement("select * from mobiles where price "
						+ "between ? and ?");
				pst.setDouble(1, startPrice);
				pst.setDouble(2, EndPrice);
				rs=pst.executeQuery();
			} 
		    catch (SQLException e) 
		    {
		
			} 
		    catch (IOException e) 
		    {
		
			}
		
		return rs;
	}
}
