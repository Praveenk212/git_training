package com.cg.customeapp.dao;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DbConnectionSetUp {
	
	FileReader fr ;
	Properties property;
	Connection con;
	private static DbConnectionSetUp dbcsu=null;
	
	private DbConnectionSetUp()
	{
		
	}
	public static DbConnectionSetUp getInstance()
	{
		if(dbcsu==null)
		{
			dbcsu=new DbConnectionSetUp();
		}
		return dbcsu;
	}
	public Connection getConnection() throws IOException, SQLException
	{
		try
		{
			fr = new FileReader("resource/oracle.properties");
			 property=new Properties();
				property.load(fr);
			    con=DriverManager.getConnection
					(property.getProperty("jdbc.url"),
					property.getProperty("jdbc.user"),
					property.getProperty("jdbc.password"));
		} 
		catch (FileNotFoundException e) 
		{
			System.out.println(e);
		}
		return con;
	}

}
