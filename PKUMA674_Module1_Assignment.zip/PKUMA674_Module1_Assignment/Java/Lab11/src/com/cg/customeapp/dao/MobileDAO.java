package com.cg.customeapp.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Map;

import com.cg.mobileapp.dto.CustomerDTO;

public interface MobileDAO 
{
	    public String purchaseMobile(int mobid,CustomerDTO cust);
	    public ResultSet allMobileDetail();
	    public String delMobile(int mobid);
	    public ResultSet getAllMobileOfRange(double startPrice,double EndPrice);

}
