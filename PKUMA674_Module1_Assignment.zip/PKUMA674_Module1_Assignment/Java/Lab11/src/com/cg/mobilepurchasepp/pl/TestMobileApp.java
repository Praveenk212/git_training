package com.cg.mobilepurchasepp.pl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.mobileapp.dto.CustomerDTO;
import com.cg.mobileapp.service.MobileService;
import com.cg.mobileapp.service.MobileServiceImpl;
public class TestMobileApp {
	public static void main(String[] args) throws SQLException 
	{
		
		ResultSet rs;
		String name;
		Long phNo;
		String email;
		int mobId;
		double startPrice;
		double endPrice;
        MobileService mobService=new MobileServiceImpl();
     	CustomerDTO custDto=new CustomerDTO();
     	
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			int choice;
			System.out.println("**************************************************************************************");
			System.out.println("1.Purchase Mobile:");
			System.out.println("2.All Mobile detail:");
			System.out.println("3.Delete Mobile based on mobile id:");
			System.out.println("4.Search mobile between price:\n");
			System.out.println("Enter your choice or any othe number than choice to exit");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1 :
				
				rs=mobService.allMobileDetail();
				System.out.println("Mobile Detail:");
				while(rs.next())
				{
					System.out.println("Mobile Id:"+rs.getString(1)
	                   +" Name:"+rs.getString(2)+" Price:"+
				rs.getString(3)+" Quantity:"+rs.getString(4));
				}
				System.out.println("*******************************************");
				System.out.println("Enter Mobile Id you want :");
				mobId=sc.nextInt();
				sc.nextLine();
				System.out.println("Enter Name:");
				name=sc.nextLine();
				while(!mobService.isValidName(name))
				{
				System.out.println("Enter Valid Name First Letter should be Captital");
				name=sc.nextLine();	
				}
				System.out.println("Enter Phone Number:");
				phNo=sc.nextLong();
				while(!mobService.isValidPhone(phNo))
				{
				System.out.println("Enter Valid Phone Number");
				phNo=sc.nextLong();	
				}
				System.out.println("Enter Customer email:");
				email=sc.next();
				while(!mobService.isValidMail(email))
				{
				System.out.println("Enter Valid email");
				email=sc.next();	
				}
				custDto.setCustName(name);
				custDto.setEmail(email);
				custDto.setPhoneNo(phNo);
				String result="";
				try
				{
					result=mobService.purchaseMobile(mobId, custDto);
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				System.out.println(result);
				break;
			case 2 :
				rs=mobService.allMobileDetail();
				System.out.println("Mobile Detail:");
				while(rs.next())
				{
					System.out.println("Mobile Id:"+rs.getString(1)
	                   +" Name:"+rs.getString(2)+" Price:"+
				rs.getString(3)+" Quantity :"+rs.getString(4));
				}
				
				break;
			case 3 :
				System.out.println("Enter Mobile Id you want to delete:");
				mobId=sc.nextInt();
				System.out.println(mobService.delMobile(mobId));
				break;
			case 4 :
				System.out.println("Enter Starting Price:");
				startPrice=sc.nextDouble();
				System.out.println("Enter ending Price:");
				endPrice=sc.nextDouble();
				rs=mobService.getAllMobileOfRange(startPrice,endPrice);
				while(rs.next())
				{
				System.out.println("Detail: \n"+"Id:"+rs.getString(1)
				                   +" \nName "+rs.getString(2)+"\nPrice "+
							rs.getString(3));
				}
				break;
				
			default :
				break;
			}
			if(choice>4)
			{
				break;
			}
			
		}
	}
}
