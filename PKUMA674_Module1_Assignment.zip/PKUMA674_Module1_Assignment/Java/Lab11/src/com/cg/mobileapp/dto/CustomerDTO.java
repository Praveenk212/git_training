package com.cg.mobileapp.dto;

public class CustomerDTO {
	
	
	@Override
	public String toString() {
		return "CustomerDTO [custName=" + custName + ", phoneNo=" + phoneNo 
				+ ", email=" + email + "]";
	}

	private String custName;
	private Long phoneNo;
	private String email;
	
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public Long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public CustomerDTO() {
		super();
	}

	public CustomerDTO(String custName, Long phoneNo,String email) {
		super();
		this.custName = custName;
		this.phoneNo = phoneNo;
		this.email = email;
	}
	
}
