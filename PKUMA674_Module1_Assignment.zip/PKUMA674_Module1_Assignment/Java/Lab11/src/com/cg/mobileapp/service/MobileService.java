package com.cg.mobileapp.service;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Map;

import com.cg.mobileapp.dto.CustomerDTO;

public interface MobileService 
{
    public String purchaseMobile(int mobid,CustomerDTO cust);
    public ResultSet allMobileDetail();
    public String delMobile(int mobid);
    public ResultSet getAllMobileOfRange(double startPrice,double EndPrice);
    
	public boolean isValidMail(String mail);
	public boolean isValidName(String name);
	public boolean isValidPhone(Long phNo);
}
