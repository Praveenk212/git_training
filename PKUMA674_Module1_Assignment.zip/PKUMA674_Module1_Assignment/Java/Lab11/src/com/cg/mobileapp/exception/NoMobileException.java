package com.cg.mobileapp.exception;

public class NoMobileException extends RuntimeException
{
     public NoMobileException()
     {
    	 super();
     }
     @Override
     public String toString()
     {
		return "This id of mobile is not present in strore ";
    	 
     }
	

}
