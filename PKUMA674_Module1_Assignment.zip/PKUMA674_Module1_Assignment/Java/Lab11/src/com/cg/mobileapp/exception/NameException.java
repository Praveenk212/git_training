package com.cg.mobileapp.exception;

public class NameException extends RuntimeException
{
	public NameException()
	{
		super();
	}
}
