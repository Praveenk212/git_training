package com.cg.mobileapp.service;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.customeapp.dao.MobileDAO;
import com.cg.customeapp.dao.MobileDAOImpl;
import com.cg.mobileapp.dto.CustomerDTO;

public class MobileServiceImpl implements MobileService
{
	Matcher matcher=null;
	private static final Pattern ValidMail=Pattern.compile("^[a-z 0-9]+@[a-z]+\\.[a-z]{2,6}$",Pattern.CASE_INSENSITIVE);
	private static final Pattern ValidName=Pattern.compile("[A-Z][a-z]*");
	private static final Pattern ValidPhone=Pattern.compile("[6-9][0-9]{9}");
	MobileDAO mobDao=new MobileDAOImpl();
	@Override
	public String purchaseMobile(int mobileid, CustomerDTO cust) 
	{
		return mobDao.purchaseMobile(mobileid, cust);
	}
	
	@Override
	public ResultSet allMobileDetail() 
	{
		return mobDao.allMobileDetail();
	}
	@Override
	public String delMobile(int mobid) 
	{
	    return 	mobDao.delMobile(mobid);
	}

	@Override
	public ResultSet getAllMobileOfRange(double startPrice,double EndPrice) 
	{
		
		return mobDao.getAllMobileOfRange(startPrice,EndPrice);
	}
	
	@Override
	public boolean isValidMail(String mail) 
	{
		matcher =ValidMail.matcher(mail);
		return matcher.matches();	
	}

	@Override
	public boolean isValidName(String name)
	{
		matcher =ValidName.matcher(name);
		return matcher.matches();	
	}

	@Override
	public boolean isValidPhone(Long phNo) 
	{
		if(phNo>0)
		{
			matcher =ValidPhone.matcher(String.valueOf(phNo));
			return matcher.matches();	
		}
		else
		{
			return false;
		}
			
	}
}
