package com.cg.eis.pl;
import java.io.IOException;
import java.util.Scanner;

import com.cg.eis.bean.*;
import com.cg.eis.service.*;

public class TestEmployee {

	public static void main(String[] args) throws IOException {
		Service s=new Service();
		Scanner sc=new Scanner(System.in);
		int empNo=0;
		System.out.println("Enter the number of employee:");
		empNo=sc.nextInt();
		
		for(int i=0;i<empNo;i++)
		{
			Employee e=s.getEmpDetail();
			String scheme=s.setInsScheme(e.getSalary());
			e.setInsScheme(scheme);
			String desig=s.setDesig(e.getSalary());
			e.setDesig(desig);
			s.WriteEmpObj(e);
		}
		System.out.println("Object Serialised");
		s.ReadEmpObj();
		
		//s.dispEmp(e);
	}

}
