import java.util.*;
import java.util.stream.Stream;

public class StreamDemo {

	public static void main(String[] args) 
	{
		Stream.of(5,7,20,1).filter(x-> x>5).skip(1).forEach(System.out::println);
		Stream.of(5,7,20,1).map((num->num+2)).forEach(System.out::println);;
	     
		//Stream.of("abcdef","ewdfs","kumar").map
	
	}

}
