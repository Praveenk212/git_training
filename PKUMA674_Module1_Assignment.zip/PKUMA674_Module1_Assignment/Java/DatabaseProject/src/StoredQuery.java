
public interface StoredQuery {
	
	String query1="SELECT * FROM emp";

}
