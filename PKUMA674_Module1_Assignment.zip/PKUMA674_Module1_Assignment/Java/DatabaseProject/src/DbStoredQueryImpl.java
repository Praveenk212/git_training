import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DbStoredQueryImpl {

	public static void main(String[] args) throws SQLException 
	{
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try {
			con=DbConnectionSetUp.getInstance().getConnection();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		ps=con.prepareStatement(StoredQuery.query1);
	    rs=ps.executeQuery();
	    while(rs.next())
	    {
	    	System.out.println("Emo No="+rs.getInt(1)+
	           " Emp Name :"+rs.getString("ename"));
	    }
		

	}

}
