import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;

public class jdbcDemo {

	public static void main(String[] args)  {
		
	//Class.forName("oracle.jdbc.driver.OracleDriver");
		FileReader fr = null;
		Properties property=null;
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		try
		{
			fr = new FileReader("resource/oracle.properties");
		    property=new Properties();
			property.load(fr);
		    con=DriverManager.getConnection
				(property.getProperty("jdbc.url"),
				property.getProperty("jdbc.user"),
				property.getProperty("jdbc.password"));
		    //Statement st=con.createStatement();
			//ResultSet rs=st.executeQuery("SELECT * FROM emp");
			//ResultSet rs2=st.executeQuery("SELECT ename FROM emp where empno=7369");
			ps=con.prepareStatement("Select ename from emp where empno=?");
			con.setAutoCommit(false);
			ps.setInt(1, 7369);
		    rs=ps.executeQuery();
//			while(rs2.next())
//			{
//				System.out.println("Ename:"+rs2.getString("ename"));
////				System.out.println("Emo No="+rs.getInt(1)+
////						           " Emp Name :"+rs.getString("ename"));
//			}
			while(rs.next())
			{
				System.out.println("Ename:"+rs.getString("ename"));
			}
			 ps=con.prepareStatement("UPDATE emp set ename=? where empno=?");
			 ps.setInt(2, 7499);
			 ps.setString(1, "praveen");
			 ps.executeUpdate();
			 ps=con.prepareStatement("Delete from emp where empno=?");
			 ps.setInt(1, 7369);
			 ps.executeUpdate();
			 
					
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				fr.close();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
