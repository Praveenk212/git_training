
public class EmployeeDetail {
	int EmpId;
	String FirstName;
	String LastName;
	float Salary;
	char Gender;
	int Age;
	public EmployeeDetail() {
		super();
		EmpId = 0;
		FirstName = "";
		LastName = "";
		Salary = 0;
		Gender = ' ';
		Age=0;
	} 
	public EmployeeDetail(int empId, String firstname,String lastname, float salary, char gender,int age) {
		super();
		this.EmpId = empId;
		this.FirstName = firstname;
		this.LastName = lastname;
		Salary = salary;
		Gender = gender;
		Age =age;
	} 
	public static float CalcAnnualSal(float salary2)
	{
		float AnnualSal;
		AnnualSal=salary2*12;
		return AnnualSal;
	}
   public String toString()
   {
	   return ("Employee Id :"+EmpId +"\n"+"Employee First Name:"+
                FirstName+"\n"+"Employee Last Name:"+
                        LastName+"\n"+"Employee Salary:"+Salary+"\n"+"Gender :"
                +Gender+"\n"+"Employee Age:"+Age+"\n"+"Annual Salary:"+
                CalcAnnualSal(Salary));
   }
}
