
public class CheckNumber {

	public static void main(String[] args) {
		int number=Integer.parseInt(args[0]);
		if(number>0)
		{
			System.out.println("Positive Number");
		}
		else if(number<0)
		{
			System.out.println("Negative Number");
		}
		else
		{
			System.out.println("You Entered 0");
		}

	}

}
