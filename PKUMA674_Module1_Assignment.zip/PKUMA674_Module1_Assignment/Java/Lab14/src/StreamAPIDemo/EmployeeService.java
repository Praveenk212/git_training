package StreamAPIDemo;

import java.util.ArrayList;
import java.util.Comparator;

public class EmployeeService {
	static double  sum=0;

	public static void main(String[] args) 
	{
		//Question 6
		EmployeeRepository empRep=new EmployeeRepository();
		empRep.getEmpList().stream()
				            .forEach(emp->sum=sum+emp.getSalary());
		System.out.println(sum);
		
		//Question 8
		Object[] sortedEmpDate=
				empRep.getEmpList().stream().sorted
				(new Comparator<Employee>()
				{
					@Override
					public int compare(Employee e1, Employee e2) {
						if(e1.getHireDate().isAfter(e2.getHireDate()))
						{
							return -1;
						}
						else
							return 1;
					}	
				}).toArray();
			System.out.println("Senior employee:"+
				sortedEmpDate[sortedEmpDate.length-1]);
		
		//Question 10
			
			empRep.getEmpList().stream().filter
			(emp->emp.getDepartment()==null).forEach(System.out::println);
			
		//Question 13
			
			empRep.getEmpList().stream().map(emp->emp.getFirstName()+" "
					+emp.getLastName()+" "+emp.getHireDate()+" "+
					emp.getHireDate().getDayOfWeek()).
			           forEach(System.out::println);
		
      //Question 14
	empRep.getEmpList().stream().filter(tempEmp->tempEmp.getHireDate()
	.getDayOfWeek().equals("SUNDAY")).map(emp->emp.getFirstName()+" "
	+emp.getLastName()+" "+emp.getHireDate()).
				      forEach(System.out::println);          
			           
	}

}
