package StreamAPIDemo;

import java.time.LocalDate;
import java.util.ArrayList;

public class EmployeeRepository 
{
	ArrayList<Employee> empList=new ArrayList();
	ArrayList<Department> deptList=new ArrayList();
	Employee e=null;
	Department d=null;

	public EmployeeRepository() {
		d=new Department(10001,"Cse",101);
		deptList.add(d);
		d=new Department(10002,"Cse",102);
		e=new Employee(1001, "Praveen", 
                "Kumar", "pk@gmail.com",
                "987654321",LocalDate.of(1993, 04,8),
                "Manager",10000d,101,d);
		empList.add(e);
		e=new Employee(1002, "Praveenk", 
                "Kumar", "pk@gmail.com",
                "987654321",LocalDate.of(1998, 04,8),
                "Manager",10002d,102,d);
		empList.add(e);
		d=null;
		e=new Employee(1003, "Praveenk", 
                "Kumar", "pk@gmail.com",
                "987654321",LocalDate.of(1990, 04,8),
                "Manager",10002d,102,d);
		empList.add(e);
	}

	public ArrayList<Employee> getEmpList() 
	{
		return empList;
	}

	public void setEmpList(ArrayList<Employee> empList)
	{
		this.empList = empList;
	}

	public ArrayList<Department> getDeptList()
	{
		return deptList;
	}

	public void setDeptList(ArrayList<Department> deptList) 
	{
		this.deptList = deptList;
	}


}
