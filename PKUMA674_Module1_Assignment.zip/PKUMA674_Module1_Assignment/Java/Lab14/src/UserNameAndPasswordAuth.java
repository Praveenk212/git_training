
public interface UserNameAndPasswordAuth {
	
	boolean isValidUser(String uName,String pass); 

}
