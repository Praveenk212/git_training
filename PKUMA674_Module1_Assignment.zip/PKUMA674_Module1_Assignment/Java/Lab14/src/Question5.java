import java.util.function.Function;

public class Question5 
{
	public static int factorial(int num)
	{
		int fact=1;
		for(int i=1;i<=num;i++)
		{
			fact=fact*i;
		}
		return fact;
	}

	public static void main(String[] args) 
	{
		Function<Integer,Integer> function=Question5::factorial;
		System.out.println("Factorial of number:"+function.apply(5));

	}

}
