import java.util.function.Function;
import java.util.function.Supplier;

public class Question4 {
	String name;
	
	public  String getName() 
	{
		return name;
	}

	public  void setName(String name) 
	{
		this.name = name;
	}
	public static Question4 getInstance()
	{
		Question4 qus=new Question4();
		return qus;
		
	}

	public static void main(String[] args)
	{
		Supplier<Question4> sup=Question4::getInstance;
		Question4 question=sup.get();
		question.setName("pk");
		System.out.println(question.getName());

	}

}
