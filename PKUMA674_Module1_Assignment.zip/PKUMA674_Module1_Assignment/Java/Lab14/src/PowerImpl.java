import java.util.Scanner;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;

public class PowerImpl 
{

	public static void main(String[] args) 
	{
	   BiFunction<Integer ,Integer,Integer> bif= (num1,num2) ->
	   {
		   return (int) Math.pow(num1, num2);  
	   };
	   Scanner sc=new Scanner(System.in);
	   System.out.println("Enter two number:");
	   int x=sc.nextInt();
	   int y=sc.nextInt();
	   System.out.println("Power of number using Bifunction:"
                           +bif.apply(x, y));
	}
}
