
public interface StringMani {
	
	String addSpaces(String s);
}
