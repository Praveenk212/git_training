import java.util.List;
import java.util.Scanner;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;

public class UserNameAndPasswordAuthImpl {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		String uname="praveen";
		String pass="praveen123";
		
//		UserNameAndPasswordAuth auth=(name,passw) ->
//		{
//			if(uname.equals(name) && pass.equals(passw))
//			{
//				return true;
//			}
//			else
//			{
//				return false;
//			}
//		};
		
		BiPredicate<String,String> bif= (name,password) ->
		   {
			   if(uname.equals(name) && pass.equals(password))
				{
					return true;
				}
				else
				{
					return false;
				}  
		   };
		System.out.println("Enter UserName");
		String username=sc.next();
		System.out.println("Enter Password:");
		String password=sc.next();
		
//		System.out.println(auth.isValidUser(username, password));
		System.out.println("Authentication reault:"+bif.test(username, password));
	}
	
}
