import java.util.Scanner;

public class StringManiImpl {

	public static void main(String[] args) 
	{
		StringMani strman=(str) ->
		{
			String res="";
			for(int i=0;i<str.length();i++)
			{
				if(i==0 || i==(str.length()-1))
				{
					res=res+str.charAt(i);
				}
				else
				{
					res=res+" "+str.charAt(i);
				}
			}
			return res;
		};
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String:");
		String str=sc.next();
		System.out.println("String with added space  :\n"+strman.addSpaces(str));
	}

}
