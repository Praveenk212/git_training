import java.util.*;
import java.sql.*;

public class TimerRefresh implements Runnable
{
	
	public void run()
	{
		int count=0;
		while(true)
		{
			count+=1;
		java.util.Date date=new java.util.Date();
		System.out.println(date.getHours()+" :"+date.getMinutes()
		                         +" :"+date.getSeconds());
		try 
		{
			Thread.currentThread().sleep(10000);
		} 
		catch (InterruptedException e) 
		{
			
			e.printStackTrace();
		}
		if(count==12)
		{
			break;
		}
		}
	}

}
