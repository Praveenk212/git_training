
public class TimerRefreshMain {

	public static void main(String[] args) 
	{
		TimerRefresh tr=new TimerRefresh();
		tr.run();

	}

}
