import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyDataThread extends Thread{
	
	FileInputStream fis=null;
	FileOutputStream fos=null;
	int count=0;
	public void run()
	{
		try 
		{
			int check=0;
			fis=new FileInputStream("C://Data//input.txt");
			fos=new FileOutputStream("C://Data//Output.txt");             
		      while((check = fis.read() )!= -1)        
		      {
		          char character = (char) check;
		          System.out.println(character);
		          if(character==' ')
		          {
		        	 fos.write(character); 
		          }
		          else
		          {
		        	  count+=1;
		        	  fos.write(character);
		          }
		          if(count==10)
		          {
		        	  count=0;
		        	  System.out.println("10 character readed.");
		        	  try
		        	  {
						Thread.currentThread().sleep(5000);
		        	  }
		        	  catch (InterruptedException e) 
		        	  {
						
						e.printStackTrace();
					}
		          }      
		      }
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	

}
