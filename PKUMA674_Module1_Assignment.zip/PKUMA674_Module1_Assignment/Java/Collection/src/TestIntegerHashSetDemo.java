import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class TestIntegerHashSetDemo {

	public static void main(String[] args) {
		HashSet<Integer> intSet=new HashSet<Integer>();
        Integer i1=new Integer(70);
        Integer i2=new Integer(20);
        Integer i3=new Integer(60);
        Integer i4=new Integer(20);
        Integer i5=new Integer(10);
        intSet.add(i1);
        intSet.add(i2);
        intSet.add(i3);
        intSet.add(i4);
        intSet.add(i5);
        
       System.out.println(intSet); 
      
       Iterator it=intSet.iterator();
       
       while(it.hasNext())
       {
    	   System.out.println(it.next());
       }

	}

}
