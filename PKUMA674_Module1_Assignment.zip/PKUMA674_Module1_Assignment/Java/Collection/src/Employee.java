
public class Employee  implements Comparable<Employee>{
	private int empId;
	private String empName;
	private float empBasicSal;
	public Employee() {
		
	}
	public Employee(int empId, String empName, float empBasicSal) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empBasicSal = empBasicSal;
	} 
	
	
	@Override
   public String toString()
   {
	   return ("\nEmployee Id :"+empId +"\n"+"Employee Name:"+
                empName+"\n"+"Employee Basic Salary:"+empBasicSal+"\n");
   }
	public float calcEmpGrossSal()
	{
		return empBasicSal;
	}
	
	@Override
	public boolean equals(Object obj)
	{
		Employee ee=(Employee)obj;
		if(this.empId==ee.empId)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	public int hashCode()
	{
		return this.empId;
	}
	@Override
	public int compareTo(Employee emp) {
		// TODO Auto-generated method stub
		
		if(this.empId<emp.empId)
		{
			return -1;
		}
		else if(this.empId==emp.empId)
		{
			return 0;
		}
		else
		{
			return +1;
		}
		
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getEmpBasicSal() {
		return empBasicSal;
	}
	public void setEmpBasicSal(float empBasicSal) {
		this.empBasicSal = empBasicSal;
	}
	
	
	
}
