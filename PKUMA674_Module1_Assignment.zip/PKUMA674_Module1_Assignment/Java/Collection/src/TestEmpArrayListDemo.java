import java.util.*;
public class TestEmpArrayListDemo {

	public static void main(String[] args) {
		
		ArrayList<Employee> empList=new ArrayList<Employee>();
		Employee e1=new Employee(1002,"Praveen",76777.98F);
		Employee e2=new Employee(1003,"PK",77997.98F);
		Employee e3=new Employee(1004,"RAHUL",987777.98F);
		Employee e4=new Employee(1002,"Praveen",76777.98F);
	  empList.add(e1);
	  empList.add(e2);
	  empList.add(e3);
	  empList.add(e4);
	  
	  System.out.println(empList);
	  
	  Iterator<Employee> itEmp=empList.iterator();
	  while(itEmp.hasNext())
	  {
		  System.out.println(itEmp.next());
	  }
		

	}

}
