import java.util.*;
public class TestIntegerTreeSetDemo {
	
	public static void main(String [] args)
	{
		TreeSet<Integer> intSet=new TreeSet<Integer>();
		intSet.add(new Integer(40));
		intSet.add(new Integer(30));
		intSet.add(new Integer(80));
		intSet.add(new Integer(40));
		intSet.add(new Integer(60));
		
		TreeSet<Employee> empSet=new TreeSet<Employee>();
		
		Employee e1=new Employee(1002,"Praveen",76777.98F);
		Employee e2=new Employee(1003,"PK",77997.98F);
		Employee e3=new Employee(1004,"RAHUL",987777.98F);
		Employee e4=new Employee(1002,"Praveen",76777.98F);
		
		empSet.add(e1);
		empSet.add(e2);
		empSet.add(e3);
		empSet.add(e4);
		//for this to work we have to override 
		//compareto method of comparable interface
		System.out.println(empSet);
		
		System.out.println(intSet);
		Iterator<Integer> iter=intSet.iterator();
		
		while(iter.hasNext())
		{
			System.out.println(iter.next());
		}
		
		
	}

}
