import java.util.Comparator;
import java.util.TreeSet;

class EmpSort implements Comparator<Employee>
{

	@Override
	public int compare(Employee emp1, Employee emp2) {
		if(emp1.getEmpBasicSal()<emp2.getEmpBasicSal())
		{
			return -1;
		}
		else if(emp1.getEmpBasicSal()==emp2.getEmpBasicSal())
		{
			return 0;
		}
		else
		{
			return +1;
		}
	}
	
}
public class TestComparator  {

	public static void main(String[] args) {
	
TreeSet<Employee> empSet=new TreeSet<Employee>(new EmpSort());
		
		Employee e1=new Employee(1002,"Praveen",76777.98F);
		Employee e2=new Employee(1003,"PK",70997.98F);
		Employee e3=new Employee(1004,"RAHUL",987777.98F);
		Employee e4=new Employee(1002,"Praveen",76777.98F);
		
		empSet.add(e1);
		empSet.add(e2);
		empSet.add(e3);
		empSet.add(e4);
        
		System.out.println(empSet);
	}

}
