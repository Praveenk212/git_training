import java.util.*;
import java.util.Map.Entry;
public class TestHashmapDemo {

	public static void main(String[] args) {
		HashMap<Long,String> phoneDir=new HashMap<Long,String>();
		phoneDir.put(88898879889L, "Praveen");
		phoneDir.put(88898879890L, "Praveenk");
		phoneDir.put(88898879891L, "Praveenku");
		phoneDir.put(88898879892L, "Praveenkum");
		phoneDir.put(88898879889L, "Praveenkuma");
		
		System.out.println(phoneDir);
		
		System.out.println("Keys");
		Set<Long> keySet=phoneDir.keySet();
		for(Long l:keySet)
		{
			System.out.println(l);
		}
		
		System.out.println("Values");
       Collection<String> allNames=phoneDir.values();
		
		for(String s:allNames)
		{
			System.out.println(s);
		}
		
		System.out.println("Keys - Value");
		
		Set<Entry<Long,String>> entrySet=phoneDir.entrySet();
		
		for(Entry e:entrySet)
		{
			System.out.println(e.getKey()+" "+e.getValue());
		}
	}

}
