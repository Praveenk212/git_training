import java.util.*;

public class TestArrayListDemo {

	public static void main(String[] args) {
		ArrayList intList=new ArrayList();
        Integer i1=new Integer(70);
        Integer i2=new Integer(20);
        Integer i3=new Integer(60);
        Integer i4=new Integer(20);
        Integer i5=new Integer(10);
        intList.add(i1);
        intList.add(i2);
        intList.add(i3);
        intList.add(i4);
        intList.add(i5);
        
       System.out.println(intList); 
       intList.remove(0);
       Iterator it=intList.iterator();
       
       while(it.hasNext())
       {
    	   System.out.println(it.next());
       }
        
        
        
	}

}
