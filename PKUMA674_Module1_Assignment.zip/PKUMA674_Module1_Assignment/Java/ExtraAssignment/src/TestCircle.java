import java.util.Scanner;

public class TestCircle {

	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number of object");
		int no=s.nextInt();
		Circle cir[]=new Circle[no];
		
		for(int i=0;i<cir.length;i++)
		{
			System.out.println("Enter the radius:");
			int rad=s.nextInt();
			cir[i]=new Circle(rad);
		}
		Circle ci=new Circle();
		ci.Sorting(cir);
		for(int i=0;i<cir.length;i++)
		{
			System.out.println("Radius:"+cir[i].getRadius());
			System.out.println("Area:"+cir[i].calcArea());
			System.out.println("Perimeter:"+cir[i].calcPerimeter());
			
		}

	}

}
