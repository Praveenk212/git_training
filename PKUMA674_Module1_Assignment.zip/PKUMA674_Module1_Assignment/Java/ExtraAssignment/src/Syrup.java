import java.util.Date;

public class Syrup extends Medicine {
	
	private String Ins="Shake well before use";

	public Syrup(String medName, int medPrice, Date expDate, Date mfgDate, String ins) {
		super(medName, medPrice, expDate, mfgDate);
		Ins = ins;
	}

	@Override
	public String toString() {
		return "Syrup [Instruction=" + Ins + ", MedicineName=" + getMedName() + ", Price()=" + getMedPrice()
				+ ", Expiry Date=" + getExpDate() + ", Manufacture Date=" + getMfgDate() + "]\n";
	}

	public Syrup() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	

}
