import java.util.Date;

public class Ointment extends Medicine{
	
	public Ointment() {
		super();
		// TODO Auto-generated constructor stub
	}


	private String Ins="Keep away from child ";
	
	public Ointment(String medName, int medPrice, Date expDate, Date mfgDate, String ins) {
		super(medName, medPrice, expDate, mfgDate);
		Ins = ins;
	}

	@Override
	public String toString() {
		return "Ointment [Instruction=" + Ins + ", MedicineName=" + getMedName() + ", Price=" + getMedPrice()
				+ ", Expiry Date=" + getExpDate() + ", Manufacture Date=" + getMfgDate() + ","
				+"]\n";
	}

	


}
