import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Random;
import java.util.Scanner;

public class TestMedicine {

	public static void main(String[] args) throws ParseException {
		
		Scanner s=new Scanner(System.in);
		Medicine MedList[]=new Medicine[1];
		Random RandObj=new Random();
		SimpleDateFormat SDF=new SimpleDateFormat("dd/mm/yyyy");
		
		for(int i=0;i<MedList.length;i++)
		{
			int RandNo=RandObj.nextInt(3);
			switch(RandNo)
			{
			case 0://Tablet
					Tablet T=new Tablet();
					System.out.println("Enter Detail Of Tablet:");
					System.out.println("Enter Name");
					T.setMedName(s.next());
					System.out.println("Enter Price");
					T.setMedPrice(s.nextInt());
					System.out.println("Enter MfgDate in format dd/mm/yyyy");
					T.setMfgDate(SDF.parse(s.next()));
					System.out.println("Enter ExpiryDate in format dd/mm/yyyy");
					T.setExpDate(SDF.parse(s.next()));
					MedList[i]=T;
					break;
			case 1://Syrup
				Syrup Sy=new Syrup();
				System.out.println("Enter Detail Of Syrup:");
				System.out.println("Enter Name");
				Sy.setMedName(s.next());
				System.out.println("Enter Price");
				Sy.setMedPrice(s.nextInt());
				System.out.println("Enter MfgDate in format dd/mm/yyyy");
				Sy.setMfgDate(SDF.parse(s.next()));
				System.out.println("Enter ExpiryDate in format dd/mm/yyyy");
				Sy.setExpDate(SDF.parse(s.next()));
				MedList[i]=Sy;
				break;
			case 2:
				Ointment O=new Ointment();
				System.out.println("Enter Detail Of Ointment:");
				System.out.println("Enter Name");
				O.setMedName(s.next());
				System.out.println("Enter Price");
				O.setMedPrice(s.nextInt());
				System.out.println("Enter MfgDate in format dd/mm/yyyy ");
				O.setMfgDate(SDF.parse(s.next()));
				System.out.println("Enter ExpiryDate in format dd/mm/yyyy");
				O.setExpDate(SDF.parse(s.next()));
				MedList[i]=O;
				break;
			default:
				System.out.println("Invalid Number");
			}
		}
		
		for(int i=0;i<MedList.length;i++)
		{
			if(MedList[i] instanceof Tablet )
			{
			System.out.println("Detail of Tablet:\n"+ MedList[i]);
			}
			else if(MedList[i] instanceof  Syrup )
			{
			System.out.println("Detail of Syrup:\n"+ MedList[i]);
			}
			else if(MedList[i] instanceof  Ointment )
			{
			System.out.println("Detail of Ointment:\n"+ MedList[i]);
			}
		}
		

	}

}
