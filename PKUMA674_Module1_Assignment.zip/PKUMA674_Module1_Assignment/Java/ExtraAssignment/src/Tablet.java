import java.util.Date;

public class Tablet extends Medicine 
{
	private String Ins="Keep it in cold place";

	public Tablet() {
		super();
	}

	public Tablet(String medName, int medPrice, Date expDate, Date mfgDate, String ins) {
		super(medName, medPrice, expDate, mfgDate);
		Ins = ins;
	}

	@Override
	public String toString() {
		return "Tablet [Instruction=" + Ins + ", MedicineName=" + getMedName() + ", Price=" + getMedPrice()
				+ ", Expiry Date=" + getExpDate() + ",  Manufacture Date=" + getMfgDate()  + "]\n";
	}

	
	

}
