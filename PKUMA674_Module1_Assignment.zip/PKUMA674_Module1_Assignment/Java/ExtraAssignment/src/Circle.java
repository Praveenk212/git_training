import static java.lang.Math.*;
public class Circle extends Shape implements Sortable{
	int radius;
	
	public Circle()
	{
		
	}
	public int getRadius()
	{
		int rad=radius;
		return rad;
	}
	public Circle(String type) {
		super();
		this.type = type;
	}

	public Circle(int radius) {
		super("Circle");
		this.radius = radius;
	}
	@Override
	public float calcArea()
	{
		return (float)(PI*radius*radius);
	}
	@Override
	public float calcPerimeter()
	{
		return (float)(2*PI*radius);
		
	}
	
	public void Sorting(Circle[] c)
	{
		int len=c.length;
		Circle temp=new Circle();
		 for (int i = 0; i < len; i++) 
	        {
	            for (int j = i + 1; j < len; j++) 
	            {
	                if (c[i].getRadius() > c[j].getRadius()) 
	                {
	                    temp = c[i];
	                    c[i] = c[j];
	                    c[j] = temp;
	                }
	            }
	        }
	}

}
