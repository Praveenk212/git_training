
public interface Sortable {
	
	public void Sorting(Circle[] c);

}
