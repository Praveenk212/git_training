import java.util.Date;

public class Medicine {
	
	private String MedName;
	private int MedPrice;
	private Date ExpDate;
	private Date MfgDate;
	public String getMedName() {
		return MedName;
	}
	public void setMedName(String medName) {
		MedName = medName;
	}
	public int getMedPrice() {
		return MedPrice;
	}
	public void setMedPrice(int medPrice) {
		MedPrice = medPrice;
	}
	public Date getExpDate() {
		return ExpDate;
	}
	public void setExpDate(Date expDate) {
		ExpDate = expDate;
	}
	public Date getMfgDate() {
		return MfgDate;
	}
	public void setMfgDate(Date mfgDate) {
		MfgDate = mfgDate;
	}
	public Medicine(String medName, int medPrice, Date expDate, Date mfgDate) {
		super();
		MedName = medName;
		MedPrice = medPrice;
		ExpDate = expDate;
		MfgDate = mfgDate;
	}
	public Medicine() {
		super();
		
	}
	

}
