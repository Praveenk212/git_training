package com.cg;

import static org.junit.Assert.*;

import org.apache.log4j.PropertyConfigurator;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CalcyTest {
	static
	{
		PropertyConfigurator.configure("resources/log4j.properties");
	}

	Calcy calcy=null;
	@Before
	public void setUp() throws Exception
	{
		calcy=new Calcy();
	}
	@After
	public void tearDown() throws Exception
	{
		calcy=null;
	}
	@Test
	public void testAddShouldReturnSumOfNumbers() 
	{
		int result=calcy.add(200, 300);
		assertEquals(500,result);	
	}
	@Test(expected=IllegalArgumentException.class)
	public void addShouldThrowIllegalArgumentException()
	{
		calcy.add(-100, 200);
	}

}
