package com.cg;

import org.apache.log4j.Logger;

public class Calcy
{
	
	private static Logger logger=Logger.getLogger(Calcy.class);
	public int add(int n1,int n2)
	{
		if(n1<0 || n2<0)
		{
			logger.info("Value of n1="+n1+ " , & n2="+n2);
			throw new IllegalArgumentException("Number cant be"
					+ " be negative");
		}
		return n1+n2;
	}
	

}
