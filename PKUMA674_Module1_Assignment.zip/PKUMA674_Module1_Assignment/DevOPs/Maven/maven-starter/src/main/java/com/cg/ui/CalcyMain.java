package com.cg.ui;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.chainsaw.Main;

import com.cg.Calcy;

public class CalcyMain {
	static
	{
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	private static Logger logger=Logger.getLogger(Main.class);

	public static void main(String[] args)
	{
		Calcy calcy=new Calcy();
		try
		{
			int result=calcy.add(1000, 2000);
			System.out.println("Result :"+result);
			logger.info("Result :"+result);
		}
		catch(IllegalArgumentException e)
		{
			logger.error("Exception :",e);
			System.out.println(e.getMessage());
		}
		
	}

}
