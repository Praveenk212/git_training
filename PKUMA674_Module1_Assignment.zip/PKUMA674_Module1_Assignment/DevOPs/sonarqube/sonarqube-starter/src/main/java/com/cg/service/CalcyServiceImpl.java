package com.cg.service;

public class CalcyServiceImpl 
{
	public int add(int num1,int num2)
	{
		System.out.println(num1);
		System.out.println(num2);
		if(num1>0 &&num2 >0 )
		{
			return num1+num2;
		}
		else
		{
			throw new 
			IllegalArgumentException("Cant process"
					+ "with negative number"
					);
		}
		
	}

}
