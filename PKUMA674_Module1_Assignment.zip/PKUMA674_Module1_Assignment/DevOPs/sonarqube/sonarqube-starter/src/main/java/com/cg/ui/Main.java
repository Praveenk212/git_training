package com.cg.ui;
import com.cg.service.CalcyServiceImpl;

public class Main {

	public static void main(String[] args)
	{    int result = 0;
		CalcyServiceImpl calcy=new CalcyServiceImpl();
      try
      {
    	 result= calcy.add(100, -200); 
      }
      catch(IllegalArgumentException e)
      {
    	System.out.println(e);
      }
      System.out.println("Result :"+result);
	}
}
