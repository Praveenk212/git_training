import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { CustomerComponent } from './customer/customer.component';
import { AdminfunctionComponent } from './adminfunction/adminfunction.component';
import { CustomerlistComponent } from './adminfunction/customerlist/customerlist.component';
import { TransactionreportComponent } from './adminfunction/transactionreport/transactionreport.component';
import { CustomeraccountComponent } from './adminfunction/customeraccount/customeraccount.component';
import { PendingservicerequestComponent } from './adminfunction/pendingservicerequest/pendingservicerequest.component';
import { CustomerfunctionalityComponent } from './customerfunctionality/customerfunctionality.component';
import { AddmoneyComponent } from './customerfunctionality/addmoney/addmoney.component';
import { RequestforserviceComponent } from './customerfunctionality/requestforservice/requestforservice.component';
import { StatusofservicerequestComponent } from './customerfunctionality/statusofservicerequest/statusofservicerequest.component';
import { TransfermoneyComponent } from './customerfunctionality/transfermoney/transfermoney.component';
import { UpdatedetailComponent } from './customerfunctionality/updatedetail/updatedetail.component';
import { ViewaccountdetailComponent } from './customerfunctionality/viewaccountdetail/viewaccountdetail.component';
import { NewcustomeraccountComponent } from './newcustomeraccount/newcustomeraccount.component';



const routes: Routes = [
  { path: 'admin', component: AdminComponent },
  {
    path: 'customer', component: CustomerComponent,
  },
  {
    path: 'adminfunction', component: AdminfunctionComponent,
    children: [
      { path: 'customerlist', component: CustomerlistComponent },
      { path: 'transactionreport', component: TransactionreportComponent },
      { path: 'customeraccount', component: CustomeraccountComponent },
      { path: 'pendingservicerequest', component: PendingservicerequestComponent }
    ]
  },
  {
    path: 'customerfunctionality', component: CustomerfunctionalityComponent,

    children: [
      { path: 'addmoney', component: AddmoneyComponent },
      { path: 'requestforservice', component: RequestforserviceComponent },
      { path: 'statusofservicerequest', component: StatusofservicerequestComponent },
      { path: 'transfermoney', component: TransfermoneyComponent },
      { path: 'updatedetail', component: UpdatedetailComponent },
      { path: 'viewaccountdetail', component: ViewaccountdetailComponent },

    ]
  },
  { path: 'newcustomeraccount', component:NewcustomeraccountComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
