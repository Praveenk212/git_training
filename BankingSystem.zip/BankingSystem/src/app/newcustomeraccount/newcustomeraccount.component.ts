import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newcustomeraccount',
  templateUrl: './newcustomeraccount.component.html',
  styleUrls: ['./newcustomeraccount.component.css']
})
export class NewcustomeraccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
