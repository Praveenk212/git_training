import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../app.component';
import { account } from '../account';
import { userinfo } from '../userinfo';

@Component({
  selector: 'app-newcustomeraccount',
  templateUrl: './newcustomeraccount.component.html',
  styleUrls: ['./newcustomeraccount.component.css']
})
export class NewcustomeraccountComponent implements OnInit {

  constructor(public appcomponent: AppComponent) { }

  ngOnInit(): void {
  }


  userName:any;
	passWord:any;
	custName:any;
	age:any;
	gender:any;
	emailId:any;
  address:any;
	aadharNo:any;
  phoneNo:any;
 
  tempUser:userinfo;
 
  submit()
  {
    this.appcomponent.userInfoDb.push(new userinfo(this.userName,this.passWord,this.custName,this.age,
      this.gender,this.emailId,this.address,this.aadharNo,this.phoneNo));
     this.appcomponent.accountDb.push(new account(this.userName)) ;
      console.log(this.appcomponent.userInfoDb);
  }


}
