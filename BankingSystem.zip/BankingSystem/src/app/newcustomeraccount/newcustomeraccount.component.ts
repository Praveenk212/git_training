import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newcustomeraccount',
  templateUrl: './newcustomeraccount.component.html',
  styleUrls: ['./newcustomeraccount.component.css']
})
export class NewcustomeraccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  userName:any;
	 passWord:any;
	custName:any;
	age:any;
	gender:any;
	emailId:any;
    address:any;
	aadharNo:any;
  phoneNo:any;
  submit()
  {

  }


}
