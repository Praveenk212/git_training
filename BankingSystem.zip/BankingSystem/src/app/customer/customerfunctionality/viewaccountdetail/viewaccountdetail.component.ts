import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewaccountdetail',
  templateUrl: './viewaccountdetail.component.html',
  styleUrls: ['./viewaccountdetail.component.css']
})
export class ViewaccountdetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
