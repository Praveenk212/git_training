import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AppComponent } from 'src/app/app.component';

@Component({
  selector: 'app-customerfunctionality',
  templateUrl: './customerfunctionality.component.html',
  styleUrls: ['./customerfunctionality.component.css']
})
export class CustomerfunctionalityComponent implements OnInit {

  constructor(private activatedroute:ActivatedRoute,public appcomponent: AppComponent) { }

  public username;
  ngOnInit(){
    var usernam=this.activatedroute.snapshot.paramMap.get('username')
     console.log("praveen"+usernam)
    this.username=usernam;
  }

}
