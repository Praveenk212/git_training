import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-requestforservice',
  templateUrl: './requestforservice.component.html',
  styleUrls: ['./requestforservice.component.css']
})
export class RequestforserviceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
