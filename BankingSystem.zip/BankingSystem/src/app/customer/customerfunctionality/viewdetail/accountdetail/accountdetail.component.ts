import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accountdetail',
  templateUrl: './accountdetail.component.html',
  styleUrls: ['./accountdetail.component.css']
})
export class AccountdetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
