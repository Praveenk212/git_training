import { Component, OnInit } from '@angular/core';
import { userinfo } from 'src/app/userinfo';
import { UserinfoService } from 'src/app/userinfo.service';
import { AppComponent } from 'src/app/app.component';
import { CustomerfunctionalityComponent } from '../../customerfunctionality.component';

@Component({
  selector: 'app-personaldetail',
  templateUrl: './personaldetail.component.html',
  styleUrls: ['./personaldetail.component.css']
})
export class PersonaldetailComponent implements OnInit {

  constructor(private userInfoservice:UserinfoService,public appcomponent: AppComponent,
   public custfun:CustomerfunctionalityComponent ) { }

    
  ngOnInit()
   {
     
  }

  tempUser:userinfo;
 

  userPersonalDetail()
  {

  }

}
