import { Component, OnInit } from '@angular/core';
import { userinfo } from 'src/app/userinfo';
import { UserinfoService } from 'src/app/userinfo.service';
import { CustomerComponent } from 'src/app/customer/customer.component';
import { AppComponent } from 'src/app/app.component';
import {ActivatedRoute}  from '@angular/router'

@Component({
  selector: 'app-personaldetail',
  templateUrl: './personaldetail.component.html',
  styleUrls: ['./personaldetail.component.css']
})
export class PersonaldetailComponent implements OnInit {

  constructor(private userInfoservice:UserinfoService,public appcomponent: AppComponent,
    private activatedroute:ActivatedRoute) { }

public username;
    
  ngOnInit()
   {
     let usernam=this.activatedroute.snapshot.paramMap.get('userName')
     console.log("praveen"+usernam)
    this.username=usernam;
  }

  tempUser:userinfo;
 

  userPersonalDetail()
  {

  }

}
