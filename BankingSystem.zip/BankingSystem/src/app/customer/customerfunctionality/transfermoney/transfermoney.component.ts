import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transfermoney',
  templateUrl: './transfermoney.component.html',
  styleUrls: ['./transfermoney.component.css']
})
export class TransfermoneyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  amount:any;
  accountNumber:any;

  transferMoney()
  {

  }

}
