import { Component, OnInit,NgModule } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  username:any;
  password:any;

  Login(event)
  {
    console.log(this.username)
    if(this.username=='customer' && this.password=='customer')
    {
      console.log(this.username)
      this.router.navigate(['customerfunctionality'])
    }
    else
    {
  window.alert("Invalid customer login credential")
    }
  }

  newUser()
  {
    this.router.navigate(['newcustomeraccount'])
  }


}
