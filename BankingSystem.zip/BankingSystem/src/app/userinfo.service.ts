import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http'
import { userinfo } from './userinfo';
import { Observable, throwError } from 'rxjs';
import {retry,catchError} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UserinfoService {

  // public userInfoDb: any[] = [];


  localurl='http://localhost:3000/user';
  constructor(private http:HttpClient) { }
  httpOptions={
    headers:new HttpHeaders({
      'Content-Type':'application/json'
    })
  }

    getUser():Observable<userinfo>
    {
      return this.http.get<userinfo>(this.localurl).pipe(retry(1), catchError(this.errorhand))
    }
    errorhand(error)
    {
      return throwError(error);
    }

}


