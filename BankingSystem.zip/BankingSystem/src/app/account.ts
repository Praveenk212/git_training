export class account {
    //Data Field Declaration

    userName: any;
    accNo: any;
    balance:any;
    serviceId: any;

    // staticRequestId:any;
    // requestId:any;
    //Constructor using all field

    constructor(userName) 
    {
        this.userName = userName;
        this.accNo=(Math.floor(Math.random()*100000000000)+1);
        this.balance="0";
        this.serviceId="0";
    }
}