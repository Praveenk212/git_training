import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pendingservicerequest',
  templateUrl: './pendingservicerequest.component.html',
  styleUrls: ['./pendingservicerequest.component.css']
})
export class PendingservicerequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
