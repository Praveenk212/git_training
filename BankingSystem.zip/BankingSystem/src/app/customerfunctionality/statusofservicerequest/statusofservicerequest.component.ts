import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-statusofservicerequest',
  templateUrl: './statusofservicerequest.component.html',
  styleUrls: ['./statusofservicerequest.component.css']
})
export class StatusofservicerequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
