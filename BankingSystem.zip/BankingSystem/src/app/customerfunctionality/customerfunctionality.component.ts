import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerfunctionality',
  templateUrl: './customerfunctionality.component.html',
  styleUrls: ['./customerfunctionality.component.css']
})
export class CustomerfunctionalityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
