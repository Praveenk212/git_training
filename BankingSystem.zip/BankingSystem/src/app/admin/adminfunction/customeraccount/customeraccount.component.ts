import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customeraccount',
  templateUrl: './customeraccount.component.html',
  styleUrls: ['./customeraccount.component.css']
})
export class CustomeraccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
