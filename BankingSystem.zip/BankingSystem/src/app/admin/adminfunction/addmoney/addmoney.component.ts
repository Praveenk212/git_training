import { Component, OnInit } from '@angular/core';
import { AppComponent } from 'src/app/app.component';

@Component({
  selector: 'app-addmoney',
  templateUrl: './addmoney.component.html',
  styleUrls: ['./addmoney.component.css']
})
export class AddmoneyComponent implements OnInit {

  constructor(private appcomponent:AppComponent) { }

  ngOnInit(): void {
  }

  amount:any;
  accountNumber:any;

  addMoney()
  {
    for(var i=0;i<this.appcomponent.accountDb.length;i++)
    {
      console.log("praveen");
      if(this.appcomponent.accountDb[i].accNo==this.accountNumber)
      {
        console.log( this.appcomponent.accountDb[i].balance +" "+this.amount)
        this.appcomponent.accountDb[i].balance=parseInt(this.appcomponent.accountDb[i].balance)+(parseInt(this.amount));
      }
    }
    console.log(this.appcomponent.accountDb);

  }

}
