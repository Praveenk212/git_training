import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addmoney',
  templateUrl: './addmoney.component.html',
  styleUrls: ['./addmoney.component.css']
})
export class AddmoneyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  amount:any;
  accountNumber:any;

  addMoney()
  {

  }

}
