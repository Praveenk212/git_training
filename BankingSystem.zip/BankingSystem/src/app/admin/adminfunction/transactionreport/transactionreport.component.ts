import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transactionreport',
  templateUrl: './transactionreport.component.html',
  styleUrls: ['./transactionreport.component.css']
})
export class TransactionreportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
