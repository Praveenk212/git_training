import { Component, OnInit } from '@angular/core';
import { userinfo } from './userinfo';
import { UserinfoService } from './userinfo.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  title = 'Online Banking System';

  public userInfoDb: userinfo[] = [];
  public userinfo;

  constructor(private userInfoservice:UserinfoService) { }

  ngOnInit()
  {
    this.loadUserData();
  }
  loadUserData()
  {
    this.userInfoservice.getMovie().subscribe((data:any)=>{this.userInfoDb=data;})
  }
}
